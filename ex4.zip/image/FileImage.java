package image;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * A package-private class of the package image.
 *
 * @author Dan Nirel
 */
public class FileImage implements Image {
    private static final Color DEFAULT_COLOR = Color.WHITE;

    private  Color[][] pixelArray;


    int newWidth;
    int newHeight ;
    BufferedImage im ;


    public FileImage(String filename) throws IOException {
        im = ImageIO.read(new File(filename));

        int origWidth = im.getWidth(), origHeight = im.getHeight();
        if(origWidth%2 != 0 ||origHeight%2 != 0 ){

            System.out.println("the given image is with odd dimensions ");
            return;
        }
        newWidth = origWidth;
        newHeight = origHeight;
        while (!isPowerOfTwo(newHeight) || !isPowerOfTwo(newWidth)) {
            if (!isPowerOfTwo(newHeight)) {
                double power = Math.ceil(Math.log(newHeight)/Math.log(2));
                newHeight = (int) Math.pow(2,power);
            }
            if (!isPowerOfTwo(newWidth)) {
                double power = Math.ceil(Math.log(newWidth)/Math.log(2));
                newWidth = (int) Math.pow(2,power);
            }
        }
        pixelArray = new Color[newHeight][newWidth];
        int partHeight = (newHeight - origHeight) /2; // the new additional heigh from one side of the image
        int partWidth = (newWidth - origWidth) /2;
        if(newWidth != origWidth || newHeight != origHeight)
        {
            // make a new white image from the new dimentions after make them power of two
            for (int i = 0; i < newHeight; i++) {
                for (int j = 0; j < newWidth; j++) {

                    pixelArray[i][j] = DEFAULT_COLOR;
                }
            }
            // draw the original image in the specific pixels
            int d= 0;
            for (int i = partHeight; i < newHeight-partHeight; i++) {
                int t=0;
                for (int j = partWidth; j < newWidth - partWidth ; j++) {

                    pixelArray[i][j] = new Color(im.getRGB(t, d));
                    t++;
                }
                d++;
            }
            // convert the full Color image to  image after expanding the original pixels  with the white
            // pixels
            BufferedImage buffImg = new BufferedImage(pixelArray[0].length,pixelArray.length,
                    BufferedImage.TYPE_INT_RGB );
            for(int x = 0 ; x < pixelArray.length ;x++){
                for(int y = 0 ; y < pixelArray[0].length ; y++){
                    int reg = pixelArray[x][y].getRGB();
                    buffImg.setRGB(y,x,reg);
                }
            }
            im = buffImg;
        }
        else
        { // the dimentions diddint change this mean that they are from power of 2
            for (int i = 0; i < origHeight; i++) {
                for (int j = 0; j < origWidth; j++) {

                    pixelArray[i][j] = new Color(im.getRGB(j, i));
                }
            }
        }




    }


    @Override
    public int getWidth() {
        //TODO: implement the function
       return newWidth;
    }

    @Override
    public int getHeight() {
        //TODO: implement the function
        return newHeight;
    }

    private boolean isPowerOfTwo(int n) {
        if (n == 0)
            return false;

        while (n != 1) {
            if (n % 2 != 0)
                return false;
            n = n / 2;
        }
        return true;
    }

    @Override
    public Color getPixel(int x, int y) {
        return  pixelArray[x][y];
    }



}

