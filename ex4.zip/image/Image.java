package image;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Facade for the image module and an interface representing an image.
 *
 * @author Dan Nirel
 */
public interface Image {


    Color getPixel(int x, int y);

    int getWidth();

    int getHeight();


    /**
     * Open an image from file. Each dimensions of the returned image is guaranteed
     * to be a power of 2, but the dimensions may be different.
     *
     * @param filename a path to an image file on disk
     * @return an object implementing Image if the operation was successful,
     * null otherwise
     */
    static Image fromFile(String filename) {
        try {
            return new FileImage(filename);
        } catch (IOException ioe) {
            return null;
        }
    }

    /**
     * Allows iterating the pixels' colors by order (first row, second row and so on).
     *
     * @return an Iterable<Color> that can be traversed with a foreach loop
     */
    default Iterable<Color> pixels() {
        return new ImageIterableProperty<>(
                this, this::getPixel);
    }

    /**
     * this function recieve num pixels in row and split the color array (image)to squared sub images
     * @param pixelsInSubImage
     * @return array list of the sub images
     */
    default ArrayList<BufferedImage> squareSubImagesOfSize(int pixelsInSubImage)  {
        ArrayList<Color[][]> samples = new ArrayList<>();
        int chunkWidth = this.getWidth() / pixelsInSubImage; //  the  size witch have equal  width and
        // height since its square ;

        ArrayList<BufferedImage> subImages = new ArrayList<>();
        // split the color array image to squares sub arrays
        int startX = 0;
        while (startX + chunkWidth <= this.getHeight()) {
            int startY = 0;
            while (startY + chunkWidth <= this.getWidth()) {
                Color[][] sample = new Color[chunkWidth][chunkWidth];
                for (int x = 0; x < chunkWidth; x++) {
                    for (int y = 0; y < chunkWidth; y++) {
                        sample[x][y] = this.getPixel(x + startX, y + startY);

                    }
                }
                samples.add(sample);
                startY += chunkWidth;
            }
            startX += chunkWidth;

        }
        // convert each sub color array to image (buffer image)
        for (var v : samples) {
            BufferedImage image = new BufferedImage(v[0].length, v.length, BufferedImage.TYPE_INT_RGB);
            for (int x = 0; x < v.length; x++) {
                for (int y = 0; y < v[x].length; y++) {
                    image.setRGB(y, x, v[x][y].getRGB());
                }
            }
            subImages.add(image);


        }
        return subImages;

    }


}
