package ascii_art.img_to_char;


import java.util.ArrayList;

import image.FileImage;
import image.Image;
import java.awt.image.BufferedImage;

import java.util.HashMap;
import java.util.Map;

public class BrightnessImgCharMatcher {

    private final FileImage img;
    private final String font;
    // this cashe map will store the pairs of (img , brightness) inorder to decrease the running time
    private final HashMap<BufferedImage, Double> cache = new HashMap<>();
    private ArrayList<BufferedImage> arr;
    private int  numCharsInRow =0 ;

    public BrightnessImgCharMatcher(Image img, String font) {
        this.img = (FileImage) img;
        this.font = font;
    }

    ///this function will calculate the brightness level of the given chars
    private double[] calculateBrightnessLevel(Character[] chs) {
        double[] brightnessArr = new double[chs.length];
        for (int x = 0; x < chs.length; x++) {
            boolean[][] cs = CharRenderer.getImg(chs[x], 16, font);
            int count = 0;
            int numOfPixels = cs.length * cs[0].length;
            for (int i = 0; i < cs.length; i++) {
                for (int j = 0; j < cs[0].length; j++) {
                    if (cs[i][j]) {
                        count++;
                    }
                }
            }
            brightnessArr[x] = (count / (double)numOfPixels);
        }
        return brightnessArr;

    }
    // this function takes brightness array and return the abrightness based on the linear stretching algo
    private double[] lineaStretch(double[] brightnessArr) {
        double[] newBrightnessArr = new double[brightnessArr.length];
        double minBrightness = brightnessArr[0];
        double maxBrightness = 0;
        for (double v : brightnessArr) {
            if (v < minBrightness) {
                minBrightness = v;
            }
            if (v > maxBrightness) {
                maxBrightness = v;
            }
        }
        for (int i = 0; i < brightnessArr.length; i++) {
            newBrightnessArr[i] = (brightnessArr[i] - minBrightness) / (maxBrightness - minBrightness);
        }
        return newBrightnessArr;


    }

    /**
     * this function is calculating the brightnes level to the given image and return this value
     * @param im
     * @return
     */
    private double averageBrightnessLevel(BufferedImage im) {
        int sum = 0;
        for (int i = 0; i < im.getHeight(); i++) {
            for (int j = 0; j < im.getWidth(); j++) {
                int color = im.getRGB(i, j);
                int red = (color & 0x00ff0000) >> 16;
                int green = (color & 0x0000ff00) >> 8;
                int blue = (color & 0x000000ff);
                double greyPixel = red * 0.2126 + green * 0.7152 + blue * 0.0722;
                sum += greyPixel;
            }

        }
        return sum /  (double)(im.getHeight() * im.getWidth() * 255);

    }

    public char[][] chooseChars(int numCharsInRow, Character[] charSet)  {
        double[] brightValue = lineaStretch(calculateBrightnessLevel(charSet));
        //as long as the number of chars in the row didn't change we will use the past submission of the
        // images in order to increase running time
        if(this.numCharsInRow != numCharsInRow){
            this.numCharsInRow = numCharsInRow;
            arr = img. squareSubImagesOfSize(this.numCharsInRow);


        }

        return matchingBrightnessToAscii(charSet, numCharsInRow, brightValue);


    }
    // this function will match the brightness values of the images to the sub image inorder to replace each
// them with the ascii char
    private char[][] matchingBrightnessToAscii(Character[] charSet, int numCharsInRow,
                                              double[] brightnessLevel)  {
        // map is a map that stores pairs of charters and their brightness value
        Map<Double, Character> map = new HashMap<>();
        int ind = 0;
        // enter the pairs to the map in the given order
        while (ind < charSet.length) {
            map.put(brightnessLevel[ind], charSet[ind]);
            ind++;
        }
        // create a list of ascii chars with the size of :
        int pixels = img.getWidth() / numCharsInRow; //first calculate the size of each sub img
        char[][] asciiArt = new char[img.getHeight() / pixels][img.getWidth() / pixels];
        // array list that will hold the sub images

        double subAverage;
        int im = 0;
        for (int i = 0; i < asciiArt.length; i++) {
            for (int j = 0; j < asciiArt[0].length; j++) {

                // check if the image brightness id already calculated
                if (cache.containsKey(arr.get(im))) { //if it takes it
                    subAverage = cache.get(arr.get(im));
                } else { /// if not calculate it
                    subAverage = averageBrightnessLevel(arr.get(im));
                    cache.put(arr.get(im), subAverage);
                }
                // find the clodest char that can be replaced by the img based on the brightness value
                double closestBrightness = closestValue(brightnessLevel, subAverage);
                asciiArt[i][j] = map.get(closestBrightness);
                im++;
            }
        }
        return asciiArt;
    }

    /**
     * this function will find the closest brightness value to the given key
     * @param sorted brightness array of the chars
     * @param key brightness value of the  calculated sub image
     * @return
     */
    private double closestValue(double[] sorted, double key) {

        double distance = Math.abs(sorted[0] - key);
        int ind = 0;
        for(int c = 1 ; c<sorted.length ;c++){
            double cDistance = Math.abs(sorted[c] - key);
            if(cDistance < distance){
                ind = c;
                distance = cDistance;
            }
        }
        return sorted[ind];

    }


}
