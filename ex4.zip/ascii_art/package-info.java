/**
 * Main module of the application.
 * @author Dan Nirel
 */
package ascii_art;