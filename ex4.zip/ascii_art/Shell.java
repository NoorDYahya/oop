package ascii_art;

import ascii_art.img_to_char.BrightnessImgCharMatcher;
import ascii_output.AsciiOutput;
import ascii_output.ConsoleAsciiOutput;
import ascii_output.HtmlAsciiOutput;
import image.Image;

import java.io.IOException;
import java.util.*;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Shell {
    private static final String CMD_EXIT = "exit";
    private static final String ALL= "all";
    private static final String SPACE= "space";
    private static final String FONT_NAME = "Courier New";
    private static final String OUTPUT_FILENAME = "out.html";
    private BrightnessImgCharMatcher charMatcher;
    private ConsoleAsciiOutput consoleAsciiOutput = new ConsoleAsciiOutput();
    private HtmlAsciiOutput htmlOutput;

    private static final int INITIAL_CHARS_IN_ROW = 64;
    private static final int MIN_PIXELS_PER_CHAR = 2;
    private final int minCharsInRow;
    private final int maxCharsInRow;
    private int charsInRow;
    private static final String INITIAL_CHARS_RANGE = "0-9";

    private Set<Character> charSet = new HashSet<>();



    public Shell(Image img){

        addChars("add "+INITIAL_CHARS_RANGE);  // by default add 0-9 to the set chars
        minCharsInRow = Math.max(1, img.getWidth()/img.getHeight());
        maxCharsInRow = img.getWidth() / MIN_PIXELS_PER_CHAR;
        charsInRow = Math.max(Math.min(INITIAL_CHARS_IN_ROW, maxCharsInRow), minCharsInRow);
        charMatcher = new BrightnessImgCharMatcher(img, FONT_NAME);
        htmlOutput = new HtmlAsciiOutput(OUTPUT_FILENAME, FONT_NAME);


    }
    public void run() {
        Scanner sc= new Scanner(System.in);
        System.out.print(" >>>");
        String strs= sc.nextLine().trim();
        String[] str = strs.split("\\s+");
        boolean isConsole = false;
        while(!str[0].equals(CMD_EXIT)){
            if(!str[0].equals("")) {
                String param = "";
                if(str.length > 1) {
                    param = str[1];
                }
            }
            System.out.print(">>> ");
            strs = sc.nextLine().trim();
            str =strs.split("\\s+");
            String cases = str[0];
            if(!cases.equals("chars") && !cases.equals("add")  &&!cases.equals("remove") &&!cases.equals(
                    "res")&&!cases.equals("render")  && !cases.equals("exit")  && !cases.equals("console") ){
                System.out.println("Did not executed due to incorrect command");
            }
            else
            {
                if(cases.equals("chars"))
                {
                    showChars();

                }
                if(cases.equals("add")) {
                    addChars(strs);
                }
                if(cases.equals("remove")) {
                    removeChars(strs);

                }
                if(cases.equals("res")) {
                    resPrint(strs);

                }
                if(cases.equals("console"))
                {
                    isConsole  = true;
                    render(isConsole);
                }
                if(cases.equals("render")) {
                    render(isConsole);

                }
            }
        }


    }
    private void showChars() {
        charSet.stream().sorted().forEach(c-> System.out.print(c + " "));
        System.out.println();
    }
    private static char[] parseCharRange(String param , String command){
//        add all    add a-m
        char[] result = new char[2];
        if(param.equals(command)){ // this mean that the user entered just add
            // without statment
            return null;
        }
        String paramWithoutAdd = param.split(command + " ")[1];
        if(paramWithoutAdd.contains("-") && paramWithoutAdd.length() == 3){

            String[] paramWithoutslash = paramWithoutAdd.split("-");
            if(paramWithoutAdd.contains(" "))
            {
                return null;
            }
            for (int i = 0; i < paramWithoutslash.length; i++) {
                result[i] = paramWithoutslash[i].charAt(0);
            }
            return result;
        }

        if(paramWithoutAdd.length() == 1){
            result[0] = paramWithoutAdd.charAt(0);
            result[1] = paramWithoutAdd.charAt(0);
            return result;
        }
        if(paramWithoutAdd.equals(ALL))
        {
            result[0] = 32;
            result[1] = 126;
            return result;
        }
        if( paramWithoutAdd.equals(SPACE)){
            result[0] = ' ';
            result[1] = ' ';
            return result;
        }
        return null;



    }
    private void addChars(String s) {
        char[] range = parseCharRange(s,"add");
        if(range != null){
            Arrays.sort(range);
            if(range[0] == 0 && range[1]==126){
                for (char i = 32; i <= 126; i++) {
                    charSet.add(i);
                }
            }
            else
            {
                for (char i = range[0]; i <= range[1]; i++) {
                    charSet.add(i);
                }
            }
        }
        if(range == null)
        {
            System.out.println("Did not add due to incorrect format");
        }
    }
    private void removeChars(String s) {
        char[] range = parseCharRange(s,"remove");
        if(range != null){
            Arrays.sort(range);
            if(range[0] == 'a' && range[1]=='z'){
                charSet.clear();
            }
            else
            {
                for (char i = range[0]; i <= range[1]; i++) {
                    charSet.remove(i);
                }
            }
        }
        if(range == null)
        {
            System.out.println("Did not add due to incorrect format");
        }
    }
    private boolean resChange(String s){
        if(s.equals("res") || s.trim().equals("res")){
            return false ;
        }
        String paramWithoutRes = s.split("res")[1].trim();
        if(paramWithoutRes.equals("up")){
            charsInRow *=2;
            return true;
        }
        if(paramWithoutRes.equals("down")){
            charsInRow /= 2;
            return true;
        }
        return false;
    }
    private void resPrint(String s){
        boolean change  = resChange(s);
        if(change){
            if(charsInRow > maxCharsInRow){ // if its exceed the boundaries from above
                System.out.println("Did not change due to exceeding boundaries");
                charsInRow /= 2; // undo inorder to replace the change from  the "rechange" function
            }
            if( charsInRow < minCharsInRow){
                System.out.println("Did not change due to exceeding boundaries");
                charsInRow *=2;  //undo the change from the function "rechange "
            }
            else{
                System.out.println("Width set to <" + charsInRow+">");
            }
        }
        else
        {
            System.out.println("Did not add due to incorrect command");
        }

    }
    private void render(boolean isConsole)  {

        Character[] charNewSet = new Character[charSet.size()];
        int i = 0;
        // stor the set content to a chars array
        for (char ch : charSet) {
            charNewSet[i] = ch;
            i++;
        }
        char[][] chars = charMatcher.chooseChars(charsInRow, charNewSet);
        if(isConsole){ // if the user entered console before so print to console
             consoleAsciiOutput.output(chars);
        }
        else
        { // by default print to html output
            htmlOutput.output(chars);
        }

    }


}
