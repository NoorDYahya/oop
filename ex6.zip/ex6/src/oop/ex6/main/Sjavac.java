package oop.ex6.main;

import oop.ex6.Parsers.FileHandle;
import oop.ex6.Parsers.ThrowException;
import java.io.IOException;

public class Sjavac {
    public static void main(String[] args) {
        try {
            if(args.length != 1) { // The program arg is invalid
                throw new IOException();
            } else { // Try to parse the file
                FileHandle.getInstance().ParseAllFile(args[0]);
            }
            System.out.println(0); // The file was successfully parsed
        } catch (IOException e) { //
            System.out.println(2);
        } catch (ThrowException e) {
            e.printStackTrace();
            System.out.println(1); // The code is illegal
        }
    }
}
