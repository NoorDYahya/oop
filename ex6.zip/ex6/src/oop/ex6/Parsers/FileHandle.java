package oop.ex6.Parsers;
import oop.ex6.Code.Types_propereties.Method;
import oop.ex6.Code.Types_propereties.Type;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class FileHandle extends GeneralHandler {
    private static FileHandle parser = new FileHandle();
    private ArrayList<String> methodsNamesInFile;
    public HashMap<String, HashMap<String, Type>> global_properties = new HashMap<>();

    /**
     * Constructor of FileParser
     */
    private FileHandle() {

        // Initiates the properties type in the has map
        this.global_properties.put("int", new HashMap<>());
        this.global_properties.put("double", new HashMap<>());
        this.global_properties.put("String", new HashMap<>());
        this.global_properties.put("char", new HashMap<>());
        this.global_properties.put("boolean", new HashMap<>());
    }

    /**
     * Returns FileParser single instance:
     * singleton design pattern
     * @return FileParser instance
     */
    public static FileHandle getInstance() {
        return parser;
    }

    /**
     * check if line is comment
     * @param line
     * @return
     */
    private boolean isComment(String line) {
        Pattern pattern = Pattern.compile("//.*");
        Matcher matcher = pattern.matcher(line);

        if(matcher.matches()){
            return true;
        }
        return false;
    }
    /**
     * check if line is empty
     * @param line
     * @return
     */

    private boolean isEmpty(String line) {
        if(line.isBlank() || line.isEmpty()){
            return true;
        }
        return false;
    }
    /**
     * check if line contain method decleration
     * @param line
     * @return
     */

    private boolean isMethodStarted(String line) {
        String[] splitLine = line.split(" ");
        if (splitLine.length > 0) {
            if(splitLine[0].equals("void")){
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * open file and put it inside array
     * @param fileName
     * @return
     * @throws IOException
     */
    public static ArrayList<String> fileToArrayList(String fileName) throws IOException {
        ArrayList<String> result = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(fileName));
        while (br.ready()) {
            result.add(br.readLine());
        }

        return result;
    }

    /**
     * validate the correctnece of the whole method
     * @param methodList
     * @param switchCount
     * @param whileSwitch
     * @param ifSwitch
     * @param line
     * @param isInsideMethod
     * @param methodParsers
     * @return
     */
    public boolean validateInsideMethod(ArrayList<String> methodList,int switchCount
            ,ArrayList<Integer> whileSwitch
            ,ArrayList<Integer> ifSwitch,String line,boolean isInsideMethod,
                                        ArrayList<ArrayList<String>> methodParsers){
        if (this.isIfLine(line)) {
            ifSwitch.add(switchCount);
        } else if (this.isWhileLine(line)) {
            whileSwitch.add(switchCount);
        } else if (this.isEnd(line)) {
            if (ifSwitch.isEmpty()) {
                if (whileSwitch.isEmpty()) {
                    isInsideMethod = false;
                    methodParsers.add(methodList);

                } else {
                    whileSwitch.remove(whileSwitch.size() - 1);
                }
            } else {
                if (whileSwitch.isEmpty()) {
                    ifSwitch.remove(ifSwitch.size() - 1);
                } else {
                    int lastCondition = ifSwitch.get(ifSwitch.size() - 1);
                    int lastWhile = whileSwitch.get(whileSwitch.size() - 1);
                    if (lastCondition > lastWhile) {
                        ifSwitch.remove(ifSwitch.size() - 1);
                    } else {
                        whileSwitch.remove(whileSwitch.size() - 1);
                    }
                }
            }
        }
        return isInsideMethod;
    }

    /**
     * checl if line does not end with one of the legal suffixes
     * @param line
     * @throws ThrowException
     */

    public static void hasLegalSuffix(String line) throws ThrowException {
        String cleanLine = line.trim();
        if (!(cleanLine.endsWith("}") || cleanLine.endsWith(";") ||
                cleanLine.endsWith("{"))) {
            throw new ThrowException("Illegal : Syntax is not valid");
        }
    }

    /**
     * iterate over file and enter the methods declerations  to array of methods in order to enable
     * calling method before declerating it
     * @param fileName
     * @return
     * @throws IOException
     * @throws ThrowException
     */
    public ArrayList<String> parseFileForMethodsOnly(String fileName) throws IOException, ThrowException {
        ArrayList<String> methodList = new ArrayList<>();
        ArrayList<String> fileLines = fileToArrayList(fileName);
        int lineCount = -1;
        for (String line : fileLines) {
            lineCount++;
            line = line.trim();
            //Empty or Comment line
            if (this.isEmpty(line) || this.isComment(line)) {
                continue;
            }

            //The line has a valid suffix
            hasLegalSuffix(line);
            if (isMethodStarted(line)) {
                String[] splitted = (line.split("void")[1]).split("\\{");
                String name = splitted[0].trim();
                checkOcuurnece(name , methodList);
                methodList.add(name);

            }
            if (isPropertyLine(line)){
                ArrayList<HashMap<String, HashMap<String, Type>>> arr = new ArrayList<>();
                arr.add(global_properties);
                ArrayList<Type> newProperties = this.getPropertiesFromLine(line, arr);
                for (Type property : newProperties) {
                    String currentType = property.getType();

                        this.global_properties.get(currentType).put(property.getName(), property);
                }
            }

        }
        this.methodsNamesInFile = methodList;
        return methodList;
    }

    private void checkOcuurnece(String name , ArrayList<String> arr) throws ThrowException {
        if(arr.contains(name)){  /// if method with tha same declaration is occurrence more than one time
            throw new ThrowException("method already defined");
        }

    }

    /**
     * iterate over the file and check line by line
     * @param fileName
     * @throws IOException
     * @throws ThrowException
     */
    public void ParseAllFile(String fileName) throws IOException, ThrowException {
        boolean isInsideMethod = false;
        ArrayList<Integer> ifSwitch = new ArrayList<>();
        ArrayList<Integer> whileSwitch = new ArrayList<>();
        int switchCount = 0;
        ArrayList<String> methodList = new ArrayList<>();
        ArrayList<ArrayList<String>> methodParsers = new ArrayList<>();
        //Get file array list
        ArrayList<String> fileLines = fileToArrayList(fileName);
        int lineCount = -1;
        ArrayList<String> MethodNames = parseFileForMethodsOnly(fileName);
        for (String line : fileLines) {
            lineCount++;
            line = line.trim();
            //Empty or Comment line
            if (this.isEmpty(line) || this.isComment(line)) {
                continue;
            }

            //The line has a valid suffix
            hasLegalSuffix(line);
            if(isMethodStarted(line)){
                methodList.add(line);
                isInsideMethod = true;
            }
            //Inside a method
            else if (isInsideMethod) {
                methodList.add(line);
                isInsideMethod = validateInsideMethod(methodList,switchCount,whileSwitch,ifSwitch,line,
                        isInsideMethod,methodParsers);

            } else if (isPropertyLine(line)) {  // normal line started with final or type outside the
                // method (global)
                ArrayList<HashMap<String, HashMap<String, Type>>> arr = new ArrayList<>();
                arr.add(global_properties);
                ArrayList<Type> newProperties = this.getPropertiesFromLine(line, arr);
                for (Type property : newProperties) {
                    String currentType = property.getType();
                    if (this.global_properties.get(currentType).containsKey(property.getName())) {
//                        throw new ThrowException("Illegal: invalid name,name is already used");
                    } else {
                        this.global_properties.get(currentType).put(property.getName(), property);
                    }
                }

            } else if (ifAssignGlobalLocalLine(line,"global")) {
                AssignValueToLocalOrGlobal(line,"global");
            } else {
                if (!(this.isEnd(line) && lineCount == fileLines.size() - 1)) {
                    throw new ThrowException("Illegal: invalid syntax");
                }
            }
        }
        if (isInsideMethod) {
            throw new ThrowException("Illlegal : file ended while method is not  even closed");
        }
        int i =0;
        HashMap<String, Method> methodsInFile = new HashMap<>();
        for(String name : methodsNamesInFile){
            Method newMethod = MethodHandle.getInstance().parseMethodLine(name);
            i++;
            methodsInFile.put(name.split("\\(")[0],newMethod);

        }
        for (ArrayList<String> methodParser : methodParsers) {
            MethodHandle.getInstance().parseMethod(methodParser, methodsInFile,methodsNamesInFile);
        }

    }
}