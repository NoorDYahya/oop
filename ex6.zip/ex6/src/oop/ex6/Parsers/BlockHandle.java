package oop.ex6.Parsers;
import oop.ex6.Code.Types_propereties.Type;
import oop.ex6.Code.Types_propereties.FactoryType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;

public class BlockHandle extends GeneralHandler {


    private String IfOrWhile;
    String type;

    /**
     * initilize spesific local arrays
     * @param isWhile
     * @param IfOrWhile
     * @param allTypes
     * @throws ThrowException
     */
    public BlockHandle(boolean isWhile, String IfOrWhile,
                       ArrayList<HashMap<String, HashMap<String, Type>>> allTypes)
            throws ThrowException {
        this.local_properties.put("int", new HashMap<>());
        this.local_properties.put("double", new HashMap<>());
        this.local_properties.put("String", new HashMap<>());
        this.local_properties.put("char", new HashMap<>());
        this.local_properties.put("boolean", new HashMap<>());
        if (isWhile) {
            type = "while";
        } else {
            type = "if";
        }
        this.IfOrWhile = IfOrWhile;
        this.verifyCondition(allTypes);
    }


    /**
     *  get the condition content between brackets (,)
     * @param line
     * @return
     * @throws ThrowException
     */
    private String getCondition(String line) throws ThrowException {
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '(') {
                for (int j = i; j < line.length(); j++) {
                    if (line.charAt(j) == ')') {
                        return line.substring(i + 1, j); // returns the condition itself
                    }
                }

                // The condition does not end with a closing bracket
                throw new ThrowException("there should be a closing bracket");
            }
        }
        //The line does not have an opening condition bracket
        throw new ThrowException("there should be a opening bracket");
    }

    /**
     * check if the str id double
     * @param str
     * @return
     */
    public static boolean isDouble(String str) {
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        return true;
    }


    /**
     * check if condition syntax and content is right
     * @param condition
     * @throws ThrowException
     */
    private void verifyConditionOperators(String condition) throws ThrowException {
        if (condition.contains("\"")) {
            throw new ThrowException("there should not be comment in the condition line ");
        }
        String[] arrayList = {".*(\\|\\|\\&\\&).*+", ".*(\\&\\&\\|\\|).*+", "(\\|\\|).*", "(\\&\\&).*", ".*"
                + "(\\|\\|)", ".*(\\&\\&)", "(\\&)[a-zA-Z0-9]+.*", "(\\|)[a-zA-Z0-9]+.*", ".*[a-zA-Z0-9]+" +
                "(\\|)", ".*[a-zA-Z0-9]+(\\&)", ".*[a-zA-Z0-9]+(\\&)[a-zA-Z0-9]+.*",
                ".*[a-zA-Z0-9]+(\\|)[a-zA-Z0-9]+.*"};
        for (int i = 0; i < arrayList.length; i++) {
            if (Pattern.matches(arrayList[i], condition)) {
                throw new ThrowException("The block condition is invalid");
            }
        }

    }

    // if varibale is exist return his propapelty
    public static Type existInProperties(String name, HashMap<String, HashMap<String, Type>> prop) {
        for (String type : prop.keySet()) {
            for (String prop_name : prop.get(type).keySet()) {
                if (prop_name.equals(name)) {
                    return prop.get(type).get(name);
                }
            }
        }
        return null;
    }

    /**
     * check if variable that contain to block is also exist outside of it (in the file)
     * @param conditionValues
     * @param allProperties
     * @throws ThrowException
     */

    public void isObjectExistInBlockOrFile(String[] conditionValues, ArrayList<HashMap<String,
            HashMap<String, Type>>> allProperties) throws ThrowException {
        boolean exist = false;
        for (String parameter : conditionValues) {
            parameter = parameter.trim();
            // if the parameter is no the saved words 'true' 'false'
            Type currentProperty;
            if (!parameter.equals("true") && !parameter.equals("false") && !isDouble(parameter)) {
//                boolean exist = false;
                currentProperty = existInProperties(parameter, this.local_properties);
                if (currentProperty != null) {
                    if (!FactoryType.getFactory().validTypesTo("boolean",
                            currentProperty.getType()) ||
                            FactoryType.getFactory().getValue(currentProperty) == null) {
                        throw new ThrowException("Illegal :Types does not match to be in condition.");
                    }
                    exist = true;
                }
                if (!exist) {
                    for (int i = allProperties.size() - 1; i >= 0; i--) {
                        currentProperty = existInProperties(parameter, allProperties.get(i));
                        if (currentProperty != null) {
                            if (FactoryType.getFactory().validTypesTo("boolean",
                                    currentProperty.getType()) ||
                                    FactoryType.getFactory().getValue(currentProperty) == null) {
                                throw new ThrowException("Illegal the one of variable does not declared in "
                                        + "the " +
                                        "file." +
                                        " ");
                            }
                            exist = true;
                        }
                    }
                    if (!exist) {
                        throw new ThrowException("Illegal the variables does not declared in " +
                                "the " +
                                "file.");
                    }
                }

            }
        }

    }

    /**
     * vertify that condition contain boolean value
     * @param allProperties
     * @throws ThrowException
     */
    private void verifyCondition(ArrayList<HashMap<String, HashMap<String, Type>>> allProperties)
            throws ThrowException {

        String conditionLine = this.IfOrWhile.replace(" ", "");

        // verifies that the condition line has the expected format
        conditionLine = conditionLine.replace(" ", "");
        if (Pattern.matches("(if|while)\\s?.*[(].*[)]\\s?.*[{]", conditionLine)) {
            String condition = getCondition(conditionLine);

            verifyConditionOperators(condition);

            //replace the OR condition to an AND condition in order to split according to '&&'
//            condition = condition.replace(OR, AND);
            String[] conditionParameters ;
            if (condition.contains("||")) {
                conditionParameters = condition.split("||");
            }
            else{
                conditionParameters = condition.split("&&");
            }

            isObjectExistInBlockOrFile(conditionParameters, allProperties);


        } else {
            throw new ThrowException("this is not how should condition look like. ");
        }

    }


    public void addPropertiesToBlock(ArrayList<Type> properties) throws ThrowException {
        for (Type property : properties) {
            if (!isExist(property.getName(), "local")) {
                this.local_properties.get(property.getType()).put(property.getName(), property);
            } else {
                throw new ThrowException("ILLEGAL_CODE");
            }
        }
    }

    /**
     * Verifies if one of the given properties exist in the block
     *
     * @param newProperties
     * @return
     */
    public boolean propertiesExistInBlock(ArrayList<Type> newProperties) {
        for (Type property : newProperties) {
            if (this.isExist(property.getName(), "local")) {
                return true;
            }
        }
        return false;
    }
}

