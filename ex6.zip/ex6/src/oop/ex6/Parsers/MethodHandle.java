package oop.ex6.Parsers;
import oop.ex6.Code.Types_propereties.FactoryType;
import oop.ex6.Code.Types_propereties.Method;
import oop.ex6.Code.Types_propereties.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;

public class MethodHandle extends GeneralHandler {

    private HashMap<String, HashMap<String, Type>> methodArguments = new HashMap<>();
    private static MethodHandle parser = new MethodHandle();
    private static final int ONE_STEP_AFTER_VOID = 5;


    /**
     * Constructor of MethodParser
     */
    private MethodHandle() {

        // Initiates the method arguments types
        this.methodArguments.put("int", new HashMap<>());
        this.methodArguments.put("double", new HashMap<>());
        this.methodArguments.put("String", new HashMap<>());
        this.methodArguments.put("char", new HashMap<>());
        this.methodArguments.put("boolean", new HashMap<>());

        // Initiates the block arguments types
        this.local_properties.put("int", new HashMap<>());
        this.local_properties.put("double", new HashMap<>());
        this.local_properties.put("String", new HashMap<>());
        this.local_properties.put("char", new HashMap<>());
        this.local_properties.put("boolean", new HashMap<>());
    }

    /**
     * Returns the single MethodParser instance - singleton design pattern
     *
     * @return MethodParser instance
     */
    public static MethodHandle getInstance() {
        return parser;
    }

    /**
     * Verifies if the method code line is an assignment line
     *
     * @param line the given line to verify
     * @return true if the line is an assignment, else false
     */
    private boolean ifAssignMethodLine(String line) {
        String[] splitLine = line.split(" ");
        if (splitLine.length == 0) {
            return false;
        }
        for (String type : this.methodArguments.keySet()) {
            if (this.methodArguments.get(type).containsKey(splitLine[0])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Verifies if the method is defined with equal parameter name
     *
     * @throws ThrowException if the method has at least two parameters with the same name
     */
    private void sameMethodParametersName(ArrayList<String> parameters) throws ThrowException {
        if (parameters.size() >= 1) {
            String[] parametersName = new String[parameters.size()];
            for (int i = 0; i < parameters.size(); i++) {
                String[] parameter = parameters.get(i).split(" ");
                if (parameter.length == 2) {
                    parametersName[i] = parameter[1];
                } else {
                    parametersName[i] = parameter[2];
                }
            }

            ///// iterate over the names and check if there is a dublications
            int i = 0;
            while (i < parametersName.length) {
                int j = i + 1;
                while (j < parametersName.length) {
                    if (parametersName[i].equals(parametersName[j])) {
                        throw new ThrowException("Illegal:the method has at least two parameters with the " +
                                "same name");
                    }
                    j++;
                }
                i++;
            }

        }
    }

    /**
     * Extracts the method name and saves it in the methodName data member
     *
     * @throws ThrowException when there is no '(' that opens the method parameter section
     */
    private String[] extractMethodDetails(String methodLineDeclaration) throws ThrowException {

        String methodName = " ";
        boolean endMethodName = false;
        boolean endMethodParams = false;
        String methodParams = " ";
        for (int i = 0; i < methodLineDeclaration.length() - 1; i++) {
            if (methodLineDeclaration.charAt(i) == '{') {
                endMethodName = true;
            } else if (!endMethodName) {
                methodName += methodLineDeclaration.charAt(i);
            } else {
                String elseString = methodLineDeclaration.substring(i);

                if (!(elseString).trim().equals("(")) {
                    throw new ThrowException("Illegal : method declaration syntax is invalid");
                }
            }
        }
        String[] list = methodName.split("\\(");
        if (list.length > 1) {  // if method accept parameters
            String name1 = list[1];
            String[] list2 = name1.split("\\)");
            methodParams += list2[0];
        } else {
            methodParams = " ";
        }
        String[] list3 = methodName.split("\\(");
        methodName = list3[0];
        return new String[]{methodName, methodParams};
    }

    /**
     * check if method name is valid
     * @param name
     * @param startWithLetter
     * @return
     * @throws ThrowException
     */
    public boolean isValidName(String name, boolean startWithLetter) throws ThrowException {
        if (name.length() == 0) {
            return false;

        } else if (Pattern.matches("\\d.*", name)) { //Name start with diit
            return false;
        } else if (startWithLetter && !(Pattern.matches("[a-zA-Z].*", name))) {
            throw new ThrowException("Illegal: method name's must be letters");
        }
        if (name.charAt(0) == '_') { // if the name start with _ it should continue with one more char
            return !name.equals("_");
        }
        return true;

    }


    public boolean isValidType(String str) { /// check if type is valid
        if (str.equals("double") ||
                str.equals("boolean") ||
                str.equals("int") ||
                str.equals("string") ||
                str.equals("char")) {
            return true;
        }
        return false;
    }

    /**
     * Verifies the method parameter type and name is matching
     *
     * @param type the given parameter type to verify
     * @param name the given parameter name to verify
     * @throws ThrowException if the type or name are invalid
     */
    private void verifyTypeName(String type, String name) throws ThrowException {
        isValidType(type);
        isValidName(name, true);

    }

    public static ArrayList<String> cleanEmptyLines(String[] strings) {
        ArrayList<String> result = new ArrayList<>();
        for (String str : strings) {
            if (!str.isEmpty() && !str.isBlank() && !str.equals("\n") && !str.equals("\r") &&
                    !Pattern.matches("(\\s|\\n|\\r)+", str)) {
                result.add(str);
            }
        }
        return result;
    }

    void addParametrToFileVariables(boolean isFinal, ArrayList<String> currentParameter)
            throws ThrowException {
        Type newVariable = FactoryType.getFactory().createMethodProperty(currentParameter.get(0),
                currentParameter.get(1), isFinal);
        HashMap<String, Type> newHashVariable = new HashMap<>();
        newHashVariable.put(newVariable.getName(), newVariable);
        methodArguments.put(newVariable.getType(), newHashVariable);
    }

    /**
     * Verifies if the method line is valid
     *
     * @throws ThrowException if a syntax error is found
     */
    private void verifyMethodLine(String methodName, String methodParams) throws ThrowException {
        methodName = (methodName).trim();
        isValidName(methodName, true);

        if (methodParams == null) {
            return;
        }

        if (methodParams.contains(",,")) {
            throw new ThrowException("Ilegal methos syntax");
        }

        boolean isFinal = false;
        methodParams = methodParams.replace("  ", " ");
        ArrayList<String> splitMethodParams = cleanEmptyLines(methodParams.split(","));
        sameMethodParametersName(splitMethodParams);

        for (String parameter : splitMethodParams) {
            ArrayList<String> currentParameter = cleanEmptyLines(parameter.split(" "));
            if (currentParameter.size() > 3 || currentParameter.size() == 1) { // valid: type name or final
                // type name
                throw new ThrowException("Illegal methos parameter syntax");
            } else if (currentParameter.size() == 2) {
                verifyTypeName(currentParameter.get(0), currentParameter.get(1));

            } else { // parameter.length = 3 so validate if it starts with final
                if ((!currentParameter.get(0).equals("final"))) {
                    throw new ThrowException("Illegal method parameter syntax");
                }
                isFinal = true;
                verifyTypeName(currentParameter.get(1), currentParameter.get(2));
                ArrayList<String> helperList = new ArrayList<>();
                helperList.add(currentParameter.get(1));
                helperList.add(currentParameter.get(2));
                currentParameter = helperList;
            }
            addParametrToFileVariables(isFinal, currentParameter);
        }
    }

    /**
     *  extract the condition content
     * @param methodLine
     * @return
     * @throws ThrowException
     */
    private String getMethodArguments(String methodLine) throws ThrowException {
        for (int i = 0; i < methodLine.length(); i++) {
            if (methodLine.charAt(i) == '(') {
                for (int j = methodLine.length() - 1; j > i; j--) {
                    if (methodLine.charAt(j) == ')') {
                        if (i == j - 1) {
                            return null;
                        }
                        return methodLine.substring(i + 1, j); // returns the method parameters
                    }
                }
                // The condition does not end with a closing bracket
                throw new ThrowException("Illegal : the emethod is invalid ");
            }
        }
        //The line does not have an opening condition bracket
        throw new ThrowException("Illegal : the emethod is invalid ");
    }

    /**
     * extract the method parameter types according to the order in the method deceleration
     *
     * @return an array of string that represents the parameter types of the method
     */
    private ArrayList<String> getMethodParamType(String line) {
        ArrayList<String> result = new ArrayList<>();
        String[] splitLine = line.split(",");
        for (String var : splitLine) {
            var = var.replace("  ", " ");
            String[] varSplit = var.split(" ");
            if (varSplit.length == 2) {  /// without  final
                result.add((varSplit[0]));
            } else if (varSplit.length == 3) {
                String type = (varSplit[1]).trim();
                result.add(type);
            }
        }
        return result;
    }

    /**
     * search for method in the array of all methods in the file such as in case and the method called is
     * not exist , return false else true
     * @param methodNames
     * @param currentName
     * @return
     */
    boolean searchForMethod(ArrayList<String> methodNames,String currentName){
        for(String name: methodNames){
            if(name.split("\\(")[0].equals(currentName)){
                return true;
            }
        }
        return false;

    }

    boolean insertVariables(String line, ArrayList<BlockHandle> blocks, boolean insideBlock)
            throws ThrowException {
        boolean doneSomething;
        ArrayList<HashMap<String, HashMap<String, Type>>> allProperties = getAllBlocksProperty(blocks);
        allProperties.add(this.methodArguments);
        allProperties.add(FileHandle.getInstance().global_properties);
        ArrayList<Type> newProperties = getPropertiesFromLine(line, allProperties);
        if (insideBlock) {
            if (blocks.get(blocks.size() - 1).propertiesExistInBlock(newProperties)) {
                throw new ThrowException("ILLEGAL_CODE");
            } else {
                blocks.get(blocks.size() - 1).addPropertiesToBlock(newProperties);
                doneSomething = true;
            }
        } else {
            for (Type newProperty : newProperties) {
                if (this.isExist(newProperty.getName(),"local") ||
                        this.methodPropertyExist(newProperty.getName())) {
                    throw new ThrowException("local name already exist");
                } else {
                    HashMap<String, Type> T = this.local_properties.get(newProperty.getType());
                    T.put(newProperty.getName(), newProperty);
                }
            }
            doneSomething = true;
        }
        return doneSomething;
    }
    void assignLocalGlobal(String line, ArrayList<BlockHandle> blocks, boolean insideBlock
            , boolean doneSomething) throws ThrowException {
        boolean assign = false;
        if (insideBlock) {
            for (BlockHandle blockHandle : blocks) {
                if (blockHandle.ifAssignGlobalLocalLine(line,"local")) {
                    blockHandle.AssignValueToLocalOrGlobal(line,"local");
                    assign = true;
                    break;
                }
            }
        }
        if (!assign) {
            if (this.ifAssignGlobalLocalLine(line,"local")) {
                AssignValueToLocalOrGlobal(line,"local");
                doneSomething = true;
            } else if (this.ifAssignMethodLine(line)) {
                AssignValueToMethodProperties(line);
                doneSomething = true;
            } else if (this.ifAssignGlobalLocalLine(line,"global")) {
                AssignValueToLocalOrGlobal(line,"global");
                doneSomething = true;
            }
        } else {
            doneSomething = true;
        }
    }
    /**
     * parse over the whole method
     * @param methodLines
     * @param existingMethods
     * @param methodNames
     * @throws ThrowException
     */
    public void parseMethod(ArrayList<String> methodLines, HashMap<String, Method> existingMethods,
                        ArrayList<String> methodNames)
        throws ThrowException {
    String line;
    ArrayList<BlockHandle> blocks = new ArrayList<>();
    boolean insideBlock = false;
    boolean normalLine = false;
    for (int i = 1; i < methodLines.size() - 1; i++) {
        line = (methodLines.get(i)).trim();
        if (this.isIfLine(line)) {
            ArrayList<HashMap<String, HashMap<String, Type>>> allProperties =
                    getAllProperties(blocks);
            blocks.add(new BlockHandle(false, line, allProperties));
            insideBlock = true;
            normalLine = true;
        } else if (this.isWhileLine(methodLines.get(i))) {
            ArrayList<HashMap<String, HashMap<String, Type>>> allProperties =
                    getAllProperties(blocks);
            blocks.add(new BlockHandle(true, line, allProperties));
            insideBlock = true;
            normalLine = true;
        }

        if (normalLine) {
            normalLine = false;
            continue;
        }

        if (isEnd(line)) {
            if (blocks.size() == 0) {
                throw new ThrowException("ILLEGAL_CODE");
            }
            blocks.remove(blocks.size() - 1);
            normalLine = true;
        } else if (this.isPropertyLine(line)) {
            normalLine = insertVariables(line, blocks,insideBlock);
        } else {
            assignLocalGlobal(line, blocks,insideBlock, normalLine);
        }

        if (!normalLine) {
            if (this.isReturn(methodLines, i)) {
                break;
            }

            if (!this.isCallToExistingMethod(line, existingMethods, blocks,methodNames)) {
                throw new ThrowException("ILLEGAL_CODE");
            }
        } else {
            normalLine = false;
        }
    }

    if (!this.isEnd(methodLines.get(methodLines.size() - 1))) {
        throw new ThrowException("ILLEGAL_CODE");
    }
}
    void parsParametersOfCalling(String[] currentParameterArray,ArrayList<BlockHandle> blocks,
                                 ArrayList<String> methodParameters) throws ThrowException {
        for (int i = 0; i < currentParameterArray.length; i++) {
            boolean parameterExist = false;
            for (int j = blocks.size() - 1; j >= 0; j--) {
                if (blocks.get(j).isExist(currentParameterArray[i],"local")) {
                    parameterExist = true;
                    if (FactoryType.getFactory().validTypesTo(methodParameters.get(i),
                            getParameterType(currentParameterArray[i], blocks.get(j).local_properties))) {
                        throw new ThrowException("ILLEGAL_CODE");
                    }
                }
            }
            if (!parameterExist) {
                if (isExist(currentParameterArray[i],"local")) {
                    parameterExist = true;
                    if (FactoryType.getFactory().validTypesTo(methodParameters.get(i),
                            getParameterType(currentParameterArray[i], local_properties))) {
                        throw new ThrowException("ILLEGAL_CODE");
                    }
                }
            }
            if (!parameterExist) {
                if (methodPropertyExist(currentParameterArray[i])) {
                    parameterExist = true;
                    if (FactoryType.getFactory().validTypesTo(methodParameters.get(i),
                            getParameterType(currentParameterArray[i], methodArguments))) {
                        throw new ThrowException("ILLEGAL_CODE");
                    }
                }
            }
            if (!parameterExist) {
                if (isExist(currentParameterArray[i],"global")) {
                    parameterExist = true;
                    if (FactoryType.getFactory().validTypesTo(methodParameters.get(i),
                            getParameterType(currentParameterArray[i],
                                    FileHandle.getInstance().global_properties))) {
                        throw new ThrowException("ILLEGAL_CODE");
                    }
                }
            }
            if (!parameterExist) {
                if (!(FactoryType.getFactory().validValue(methodParameters.get(i),
                        currentParameterArray[i]))) {
                    throw new ThrowException("ILLEGAL_CODE");
                }
            }
        }
    }
    void parsMethod(ArrayList<BlockHandle> blocks, HashMap<String, Method> existingMethods,
                    String line , String[] methodCall) throws ThrowException {
        Method existingMethod = existingMethods.get(methodCall[0]);
        ArrayList<String> methodParameters = existingMethod.getMethodParameterType();
        String currentMethodParameters = getMethodArguments(line);
        String[] currentParameterArray;
        if (currentMethodParameters == null || currentMethodParameters.isEmpty()) {
            currentParameterArray = new String[0];
        } else {
            currentParameterArray = currentMethodParameters.split(",");
        }
        parsParametersOfCalling(currentParameterArray,blocks,methodParameters);

    }
    /**
     * handle the method calling and check the validity of all it parts
     * @param line
     * @param existingMethods
     * @param blocks
     * @param methodNames
     * @return
     * @throws ThrowException
     */
    private boolean isCallToExistingMethod(String line, HashMap<String, Method> existingMethods,
                                           ArrayList<BlockHandle> blocks , ArrayList<String> methodNames)
            throws ThrowException {
        line = line.replace(" ", "");
        String[] methodCall = line.split("\\(");

        if (!line.endsWith(";")) {
            throw new ThrowException("Illegal : calling methos should end with ;");
        }

        if (!(searchForMethod(methodNames,methodCall[0]))) { // verify the method exist
            throw new ThrowException("ILLEGAL_CODE");

        } else {// The method was found
            parsMethod(blocks,existingMethods,line,methodCall);
        }
        return true;
    }
    /**
     * Get all block properties
     *
     * @param blocks Blocks list
     * @return Properties list
     */
    private ArrayList<HashMap<String, HashMap<String, Type>>> getAllProperties
    (ArrayList<BlockHandle> blocks) {
        ArrayList<HashMap<String, HashMap<String, Type>>> allProperties = new ArrayList<>();
        for (int j = blocks.size() - 1; j >= 0; j--) {
            allProperties.add(blocks.get(j).local_properties);
        }
        allProperties.add(local_properties);
        allProperties.add(methodArguments);
        allProperties.add(FileHandle.getInstance().global_properties);
        return allProperties;
    }

    /**
     * Verifies that the method deceleration code line is valid
     *
     * @param methodLines the given method code lines to verify
     * @return Method object if the deceleration line is valid
     * @throws ThrowException when the method deceleration line is invalid
     */
    public Method parseMethodLine(String methodLines) throws ThrowException {
        String line = (methodLines).trim();
        String[] methodDetails = extractMethodDetails(line);
        verifyMethodLine(methodDetails[0], methodDetails[1]);
        ArrayList<String> methodParamType = this.getMethodParamType(methodDetails[1]);
        return new Method(methodParamType, methodDetails[0]);
    }

    /**
     * Verifies if the given method code line is a return statement line
     *
     * @param methodLines the given method code lines to verify
     * @param lineIndex   the given code line to verify that it is a return statement line in the method
     * @return true if the code line is a valid return statement line, else false
     * @throws ThrowException when the code line is recognized as a return statement line but is invalid
     */
    private boolean isReturn(ArrayList<String> methodLines, int lineIndex) throws ThrowException {
        String returnLine = (methodLines.get(lineIndex)).trim();
        if (returnLine.equals("return;")) {

            String nextLine = methodLines.get(lineIndex + 1).replace(" ", "");
            if (!(nextLine.equals("}"))) {
                throw new ThrowException("Illegal:");
            }
            return true;
        } else {
            if (returnLine.contains("return")) {
                throw new ThrowException("ILLEGAL_CODE");
            }
            return false;
        }

    }

    /**
     * Assigns values to method properties
     *
     * @param line the given code line the assignment happens
     * @throws ThrowException when the assignment is invalid
     */
    private void AssignValueToMethodProperties(String line) throws ThrowException {
        line = (line).trim();
        String[] splitLine = line.split("=");
        if (splitLine.length != 2) {
            throw new ThrowException("Illegal : there should be two sides for assinment ");
        }
        String value = (splitLine[1]).trim();
        String name = (splitLine[0]).trim();
        if (!this.methodPropertyExist(name)) {
            throw new ThrowException("Illegal: ");
        }
        if (value.endsWith(";")) {
            value = value.substring(0, value.length() - 1);
        }

        String propertyType = this.getParameterType(name, this.methodArguments);
        if (FactoryType.getFactory().validValue(propertyType, value)) {
            throw new ThrowException("ILLEGAL_CODE");
        }

        Type currentProperty = FactoryType.getFactory().getUpdatedProperty(
                this.methodArguments.get(propertyType).get(name), value);

        this.methodArguments.get(propertyType).put(name, currentProperty);
    }

    /**
     * Verifies if the given property exist according to a given property name
     *
     * @param name the given property name to verify
     * @return true if the property exist else false
     */
    public boolean methodPropertyExist(String name) {
        for (String type : this.methodArguments.keySet()) {

            if (!this.methodArguments.get(type).containsKey(name)) {
                continue;
            } else {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns all the blocks properties
     *
     * @param allBlocks the given blocks to extract their properties
     * @return an all the blocks properties
     */
    private ArrayList<HashMap<String, HashMap<String, Type>>> getAllBlocksProperty(
            ArrayList<BlockHandle> allBlocks) {
        ArrayList<HashMap<String, HashMap<String, Type>>> result = new ArrayList<>();
        for (int i = 0; i < allBlocks.size(); i++) {
            result.add(allBlocks.get(i).local_properties);
        }
        return result;
    }
}