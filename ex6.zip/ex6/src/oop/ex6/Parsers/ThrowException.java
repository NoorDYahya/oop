package oop.ex6.Parsers;

/**
 * exeption class that extends  the Exception and assigned to the suitable message
 */
public class ThrowException extends Exception {

    public ThrowException(String message) {
        super(message);
    }
}
