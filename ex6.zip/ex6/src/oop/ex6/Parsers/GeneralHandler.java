package oop.ex6.Parsers;
import oop.ex6.Code.Types_propereties.FactoryType;
import oop.ex6.Code.Types_propereties.Type;
import java.util.ArrayList;
import java.util.HashMap;

public class GeneralHandler {

    private static final int ONE_STEP_AFTER_FINAL = 6;
    protected HashMap<String, HashMap<String, Type>> local_properties = new HashMap<>();

    /**
     * Verify if the given code line is a property creation line
     *
     * @param line
     * @return true ,false
     */
    protected boolean isPropertyLine(String line) {
        String[] splitted = line.split(" ");
        if (splitted.length == 0) {
            return false;
        }
        return FactoryType.getFactory().isValidType(splitted[0]) ||
                splitted[0].equals("final");

    }

    /**
     * Verify if the given code line is a while loop line
     *
     * @param line the given code line to verify
     * @return tue if it is else false
     */
    protected boolean isWhileLine(String line) {

        line = line.trim();
        String[] split = line.split(" ");
        if (split.length == 0) {
            return false;
        }
        return split[0].startsWith("while" + "{") ||
                split[0].equals("while");
    }



    /**
     * Verifies if the given code line is a "if" condition line
     *
     * @param line
     * @return tue if it is else false
     */
    protected boolean isIfLine(String line) {
        line = line.trim();
        String[] split = line.split(" ");
        if (split.length == 0) {
            return false;
        }
        return split[0].startsWith("if" + "{") ||
                    split[0].equals("if");


    }

    /**
     * Verifies if the code line ends with the bracket '}'
     *
     * @param line
     * @return tue if it is else false
     */
    protected boolean isEnd(String line) {
        return line.replace(" ", "").equals("}");
    }

    /**
     * validate the assignment line is valid: assign values from the same type
     * @param item
     * @param properties
     * @param isFinal
     * @param type
     * @param result
     * @param waitForValue
     * @throws ThrowException
     */
    public void validateAssignmentInLine(String item ,  ArrayList<HashMap<String, HashMap<String, Type>>>
            properties,boolean isFinal ,String type,ArrayList<Type> result,ArrayList<String> waitForValue
    ) throws ThrowException{
        String[] splitItem = item.split("=");
        if (splitItem.length != 2) {
            throw new ThrowException("Illegal assignment operation should have two side");
        }
        String name = (splitItem[0]).trim();
        String value = (splitItem[1]).trim();

        if (FactoryType.getFactory().isValidName(name)) {
            for (HashMap<String, HashMap<String, Type>> properties_hash : properties) {
                Type existProp = existInProperties(value, properties_hash);
                if (existProp != null) {
                    value = FactoryType.getFactory().getValue(existProp);
                    if (value == null && !existProp.isMethodProperty()) {
                        throw new ThrowException("Illegal value ");
                    }
                }
            }
            if (!FactoryType.getFactory().validValue(type, value)) {
                throw new ThrowException("Illegal value does not match the variable type.");
            } else {
                for (String waitItem : waitForValue) {
                    result.add(FactoryType.getFactory().createProperty(type, waitItem, value, isFinal));
                }
                result.add(FactoryType.getFactory().createProperty(type, name, value, isFinal));
            }

        } else {
            throw new ThrowException("Illegal the chosen name variable is incorrect ");
        }
    }
    // check if exist properties
    public static Type existInProperties(String name, HashMap<String, HashMap<String, Type>> prop) {
        for (String type : prop.keySet()) {
            for (String prop_name : prop.get(type).keySet()) {
                if (prop_name.equals(name)) {
                    return prop.get(type).get(name);
                }
            }
        }
        return null;
    }
    public boolean validateEntireLine (String[] splitLine , boolean ended,ArrayList<HashMap<String,
            HashMap<String, Type>>>
            properties,boolean isFinal ,String type,ArrayList<Type> result,ArrayList<String> waitForValue)
            throws ThrowException{
        for (String item : splitLine) {
            item = item.trim();
            if (item.endsWith(";")) {
                /// check if the last word in the line is end with ";"
                if ((splitLine[splitLine.length - 1]).trim().equals(item)) {

                    item = item.substring(0, item.length() - 1);
                    ended = true;
                } else {
                    throw new ThrowException("Illegal End bracket should be the last char in the line");

                }
            }

            if (item.contains("=")) {

                validateAssignmentInLine(item,properties,isFinal,type,result,waitForValue);

            } else { // if there is no assignment in the line
                if (!FactoryType.getFactory().isValidName(item)) {
                    throw new ThrowException("Illegal name syntax countered");
                } else {
                    waitForValue.add(item);
                }
            }
        }
        return ended;

    }
    /**
     * create properties from given line
     */
    protected ArrayList<Type> getPropertiesFromLine(String line,
                                                        ArrayList<HashMap<String, HashMap<String, Type>>>
                                                                properties)
            throws ThrowException {
        line = line.trim();
        int firstIndex = 0;
        int spaceIndex = line.indexOf(" ");
        String currentString = line.substring(firstIndex, spaceIndex);
        boolean isFinal = false;
        String type;
        if (currentString.equals("final")) {
            isFinal = true;
            spaceIndex = line.substring(ONE_STEP_AFTER_FINAL).indexOf(" ");

            if (spaceIndex == -1) {
                throw new ThrowException("Illegal there should be at least 2 words after final.");
            }
            // from now on handle line without final
            line = line.substring(ONE_STEP_AFTER_FINAL).trim();
        }
        ///get the type
        String[] firstWord = line.split(" ");
        currentString = firstWord[0];
        if (FactoryType.getFactory().isValidType(currentString)) {
            type = currentString;
        } else {
            throw new ThrowException("Illegal type or code");
        }

        line = (line.substring(spaceIndex)).trim();
        String[] splitLine = line.split(",");
        ArrayList<String> waitForValue = new ArrayList<>();
        ArrayList<Type> result = new ArrayList<>();
        boolean lineEnded = false;
        lineEnded = validateEntireLine(splitLine,lineEnded,properties,isFinal,type,result,waitForValue);
        if (!lineEnded) {
            throw new ThrowException("Illegal : return statment incorrect ");
        }

        if (waitForValue.size() > 0) {
            for (String name : waitForValue) {
                if (isFinal) {
                    throw new ThrowException("Illegal final variable should be declared and assigined at " +
                            "the same time");
                }
                result.add(FactoryType.getFactory().createProperty(type, name,
                        null, false));
            }
        }

        return result;
    }

    /**
     * Verifies if the code line is an assignment line for global  and local properties
     * @param line
     * @param localOrGlobal global or local
     * @return false if it is not in any one else true
     */


    public   boolean ifAssignGlobalLocalLine(String line,String localOrGlobal){
        line = line.trim();
        String[] split = line.split(" ");
        if(split.length == 0){
            return false;
        }
        if(localOrGlobal.equals("local")){
            for (String type : this.local_properties.keySet()) {
                if (this.local_properties.get(type).containsKey(split[0]) ||
                        this.local_properties.get(type).containsKey(split[0])) {
                    return true;
                }
            }
        }
        if(localOrGlobal.equals("global")){
            for (String type : FileHandle.getInstance().global_properties.keySet()) {
                if (FileHandle.getInstance().global_properties.get(type).containsKey(split[0]) ||
                        FileHandle.getInstance().global_properties.get(type).containsKey(split[0])) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     *  check if local or global properites contain the given value
     * @param name
     * @param localOrGlobal
     * @return false if not found
     */
    public boolean isExist(String name,String localOrGlobal ){
        if(localOrGlobal.equals("local")){
            for (String type : this.local_properties.keySet()) {
                if (this.local_properties.get(type).containsKey(name)) {
                    return true;
                }
            }
            return false;
        }
        else{ /// global
            for (String type : FileHandle.getInstance().global_properties.keySet()) {
                if (FileHandle.getInstance().global_properties.get(type).containsKey(name)) {
                    return true;
                }
            }
            return false;
        }
    }



    /**
     * Returns the property type according to the property name
     *
     * @param name
     * @param properties all the existing properties to verify in
     * @return the given property type, if the property was not found then returns an empty string
     */
    protected String getParameterType(String name,
                                      HashMap<String, HashMap<String, Type>> properties) {
        for (String type : properties.keySet()) {
            for (String propName : properties.get(type).keySet()) {
                if (name.equals(propName)) {
                    return type;
                }
            }
        }
        return " ";
    }

    /**
     * check the assignment to local and global variable and add them to the suitable properitiy array
     * @param line
     * @param localGlobal
     * @throws ThrowException
     */
    public void AssignValueToLocalOrGlobal(String line , String localGlobal) throws ThrowException{
        if(localGlobal.equals("local")){
            line = line.trim();
            String[] split = line.split("=");
            if (split.length != 2) {
                throw new ThrowException("Illegal assignment there should be value after =.");
            }
            String value = (split[1].trim());
            String name = split[0].trim();

            if (!this.isExist(name,"local")) {
                throw new ThrowException("Illegal case the string should be declared before assignment. ");
            }
            if (value.endsWith(";")) {
                value = value.substring(0, value.length() - 1);
            }
            String propertyType = this.getParameterType(name, this.local_properties);
            if (!FactoryType.getFactory().validValue(propertyType, value)) {
                throw new ThrowException("IIlegal cas the value is not matching with the type.");
            }

            Type current = FactoryType.getFactory().getUpdatedProperty(
                    this.local_properties.get(propertyType).get(name), value);

            this.local_properties.get(propertyType).put(name, current);
        }
        else{
            line = line.trim();
            String[] splitLine = line.split("=");
            if (splitLine.length != 2) {
                throw new ThrowException("Illegal assignment there should be value after =.");
            }
            String value = splitLine[1].trim();
            String name = splitLine[0].trim();

            if (!this.isExist(name,"global")) {
                throw new ThrowException("Illegal case the string should be declared before assignment.");
            }
            String propertyType = this.getParameterType(name, FileHandle.getInstance().global_properties);
            if (value.endsWith(";")) {
                value = value.substring(0, value.length() - 1);
            }
            if (!FactoryType.getFactory().validValue(propertyType, value)) {
                throw new ThrowException("IIlegal cas the value is not matching with the type.");
            }

            Type current = FactoryType.getFactory().getUpdatedProperty(
                    FileHandle.getInstance().global_properties.get(propertyType).get(name), value);

            FileHandle.getInstance().global_properties.get(propertyType).put(name, current);
        }
    }

}
