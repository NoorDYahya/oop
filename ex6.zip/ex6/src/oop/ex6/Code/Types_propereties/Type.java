package oop.ex6.Code.Types_propereties;


/**
 * Super class that represent a variable
 */
public abstract class Type {
    protected String name;
    protected String type;
    protected boolean isFinal;
    protected boolean methodProperty;
    protected boolean isNull;

    /**
     * Constructor of Property
     *
     * @param name    the given variable name
     * @param type    the given variable type
     * @param isFinal true when the variable is declared final else false
     * @param method  true when the variable is local in a method else false, i.e is global
     */
    public Type(String name, String type, boolean isFinal, boolean method) {
        this.name = name;
        this.type = type;
        this.isFinal = isFinal;
        this.methodProperty = method;
    }

    /**
     * returns property name
     *
     * @return property name
     */
    public String getName() {
        return name;
    }

    public boolean isMethodProperty() {
        return this.methodProperty;
    }

    public boolean isFinal() {
        return this.isFinal;
    }

    /**
     * returns property type
     *
     * @return property type
     */
    public String getType() {
        return this.type;
    }
}

