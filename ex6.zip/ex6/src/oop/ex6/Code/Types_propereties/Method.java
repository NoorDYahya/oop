package oop.ex6.Code.Types_propereties;
import java.util.ArrayList;
import java.util.HashMap;
public class Method {
    protected String methodName;
    protected HashMap<String, HashMap<String, Type>> properties;
    protected ArrayList<Method> executeMethods;
    protected ArrayList<String> parameterType;

    /**
     * Constructor of Method
     * @param methodParameterType an array that represent the method parameter types according to the order
     * in the method deceleration
     * @param name the method name
     */
    public Method(ArrayList<String> methodParameterType, String name) {

        this.properties = new HashMap<>();
        this.executeMethods = new ArrayList<>();
        this.parameterType = methodParameterType;
        this.methodName = name;
    }

    /**
     * Returns the method parameter type array
     * @return method parameter type array according to the order of deceleration in the method
     */
    public ArrayList<String> getMethodParameterType (){
        return parameterType;
    }
}

