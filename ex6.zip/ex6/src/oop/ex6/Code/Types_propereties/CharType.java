package oop.ex6.Code.Types_propereties;

public class CharType extends Type {

    protected char value;

    /**
     * Constructor of CharProperty
     *
     * @param name    the given variable name
     * @param type    the given variable type
     * @param isFinal true when the variable is declared final else false
     * @param method  true when the variable is local in a method else false, i.e is global
     * @param value   the variable value
     */
    public CharType(String name, String type, boolean isFinal, boolean method, Character value) {
        super(name, type, isFinal, method);
        if (value != null) {
            this.value = value;
        } else {
            isNull = true;
        }
    }

    /**
     * setter
     *
     * @param value
     */
    public void setValue(char value) {
        this.value = value;
    }

    /**
     * getter
     *
     * @return
     */
    public char getValue() {
        return value;
    }

}
