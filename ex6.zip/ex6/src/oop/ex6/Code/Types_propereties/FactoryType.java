package oop.ex6.Code.Types_propereties;

//import oop.ex6.Exeptions;
import oop.ex6.Parsers.ThrowException;
/**
 * PropertyFactory class creates all different properties types, uses the Singleton design pattern
 */

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FactoryType {


    // creates a single instance of Property Factory - singleton design
    private static FactoryType factory = new FactoryType();
    private final Pattern stringP;
    private final Pattern charP;

    private final String Exeption = "Illegal code";

    // private constructor - singleton design
    private FactoryType() {
        stringP = Pattern.compile("\".*\"");
        charP = Pattern.compile("'.'");
    }

    /**
     * Verifies if the given String one of the valid variable types
     *
     * @param str the given string to verify
     * @return true if the String is a valid variable type else false
     */
    public boolean isValidType(String str) {
        if (str.equals("double") ||
                str.equals("boolean") ||
                str.equals("int") ||
                str.equals("String") ||
                str.equals("char")) {
            return true;
        }
        return false;
    }

    /**
     * returns the single PropertyFactory instance - singleton design
     *
     * @return PropertyFactory instance
     */
    public static FactoryType getFactory() {
        return factory;
    }

    /**
     * Verifies that the given string is a valid variable name
     *
     * @param name the given string to verify
     * @return true if the string is a valid name else false
     */
    public boolean isValidName(String name) {
        if (name.length() == 0) {
            return false;

        } else if (Pattern.matches("\\d.*", name)) { //Name start with diit
            return false;
        }
        if (name.charAt(0) == '_') { // if the name start with _ it should continue with one more char
            return !name.equals("_");
        }
        return true;

    }

    public static boolean isInt(String str) {
        try {
            Integer.parseInt(str);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        return true;
    }

    public static boolean isDouble(String str) {
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        return true;
    }

    /**
     * Verifies that the variable assignment is valid according to the variable type
     *
     * @param type  the given variable type
     * @param value the given variable value to be assigned
     * @return true if the assignment is valid else false
     */
    public boolean validValue(String type, String value) {
        if (value == null) {
            return true;
        }
        if (type.equals("String")) {
            Matcher match = stringP.matcher(value);
            return match.matches();
        }

        if (type.equals("double")) {
            return isDouble(value);
        }
        if (type.equals("int")) {
            return isInt(value);
        }
        if (type.equals("char")) {
            Matcher match = charP.matcher(value);
            return match.matches();
        }
        if (type.equals("boolean")) {
            return isDouble(value) || value.equals("true") || value.equals("false") || isInt(value);
        }
        return false;


    }

    public String getValue(Type type) {
        if (type.isNull) {
            return null;
        }
        if (type.getType().equals("String")) {
            return "\"" + ((StringType) type).getValue() + "\"";
        }
        if (type.getType().equals("double")) {
            return String.valueOf(((DoubleType) type).getValue());
        }
        if (type.getType().equals("int")) {
            return String.valueOf(((IntType) type).getValue());
        }
        if (type.getType().equals("char")) {
            return "'" + ((CharType) type).getValue() + "'";
        }
        if (type.getType().equals("boolean")) {
            return String.valueOf(((BooleanType) type).getValue());
        }
        return null;
    }

    /**
     * Verifies that the assignment of the variable is legal from one variable to another
     *
     * @param toType   The variable that wants to be assigned to
     * @param fromType The variable that wants to be assigned from
     * @return true if the assignment is valid, else false
     */
    public boolean validTypesTo(String toType, String fromType) {
        if (toType.equals(fromType)) {
            return true;
        } else {
            if (toType.equals("boolean")) {
                return fromType.equals("double") || fromType.equals("int");
            } else {
                return toType.equals("double") || fromType.equals("int");
            }
        }
    }


    public Type createProperty(String type, String name,
                               String value, boolean isFinal) throws ThrowException {
        if (!isValidType(type)) {
            throw new ThrowException("Illegal type.");
        }
        if(!validValue(type, value)){
            throw new ThrowException("Illegal value.");
        }
        if(!isValidName(name)){
            throw new ThrowException("Illegal name.");
        }

        if (value != null) { // decleration with initialization
            if (type.equals("String")) {
                return new StringType(name,
                        type, isFinal, false, value);
            }

            if (type.equals("double")) {
                return new DoubleType(name,
                        type, isFinal, false, Double.parseDouble(value));
            }
            if (type.equals("int")) {
                return new IntType(name,
                        type, isFinal, false, Integer.parseInt(value));
            }
            if (type.equals("char")) {
                return new CharType(name,
                        type, isFinal, false, value.charAt(1));
            }
            if (type.equals("boolean")) {
                return new BooleanType(name,
                        type, isFinal, false, Boolean.parseBoolean(value));
            }

        } else { // just decleration


            if (type.equals("String")) {
                return new StringType(name,
                        type, isFinal, false, null);
            }

            if (type.equals("double")) {
                return new DoubleType(name,
                        type, isFinal, false, null);
            }
            if (type.equals("int")) {
                return new IntType(name,
                        type, isFinal, false, null);
            }
            if (type.equals("char")) {
                return new CharType(name,
                        type, isFinal, false, null);
            }
            if (type.equals("boolean")) {
                return new BooleanType(name,
                        type, isFinal, false, null);
            }

        }
        return null;
    }


    public Type createMethodProperty(String type, String name, boolean isFinal)
            throws ThrowException {
        if (!isValidType(type) || !isValidName(name)) {
            throw new ThrowException(Exeption);
        }
        if (type.equals("String")) {
            return new StringType(name,
                    type, isFinal, true, null);
        }

        if (type.equals("double")) {
            return new DoubleType(name,
                    type, isFinal, true, null);
        }
        if (type.equals("int")) {
            return new IntType(name,
                    type, isFinal, true, null);
        }
        if (type.equals("char")) {
            return new CharType(name,
                    type, isFinal, true, null);
        }
        if (type.equals("boolean")) {
            return new BooleanType(name,
                    type, isFinal, true, null);
        }

        return null;
    }

    public Type getUpdatedProperty(Type prop, String value) throws ThrowException {
        if (prop.isFinal) {
            throw new ThrowException(Exeption);
        }

        if (prop.getType().equals("String")) {
            ((StringType) prop).setValue(value.substring(1, value.length() - 1));
        }
        if (prop.getType().equals("double")) {
            ((DoubleType) prop).setValue(Double.parseDouble(value));
        }
        if (prop.getType().equals("int")) {
            ((IntType) prop).setValue(Integer.parseInt(value));
        }
        if (prop.getType().equals("char")) {
            ((CharType) prop).setValue(value.charAt(1));
        }
        if (prop.getType().equals("boolean")) {
            if (isDouble(value)) {
                ((BooleanType) prop).setValue(Double.parseDouble(value) != 0);
            } else {
                ((BooleanType) prop).setValue(Boolean.parseBoolean(value));
            }
        }
        return prop;
    }
}
