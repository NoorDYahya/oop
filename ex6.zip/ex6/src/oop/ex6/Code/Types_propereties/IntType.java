package oop.ex6.Code.Types_propereties;

public class IntType extends Type{
    protected int value;

    /**
     * constructor
     * @param name
     * @param type
     * @param isFinal
     * @param method
     * @param value
     */
    public IntType(String name, String type, boolean isFinal, boolean method, Integer value) {
        super(name, type, isFinal, method);
        if (value != null) {
            this.value = value;
        } else {
            isNull = true;
        }
    }

    /**
     * Set int property value
     * @param value the given value to set
     */
    public void setValue(int value) {
        this.value = value;
        isNull = false;
    }

    /**
     * return the int property value
     * @return int property value
     */
    public int getValue() {
        return value;
    }
}
