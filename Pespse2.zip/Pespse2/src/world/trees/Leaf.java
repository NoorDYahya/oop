package world.trees;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.components.ScheduledTask;
import danogl.components.Transition;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import world.Block;

import java.util.ArrayList;
import java.util.Random;

public class Leaf extends GameObject {

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     * Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     * the GameObject will not be rendered.
     */
    Vector2 topLeftCorner;
    Vector2 dimensions;
    Renderable renderable;
    GameObjectCollection gameObject;
    float topLeftCornerX;
    int seed;
    Random random;
    GameObject leaf;
    Transition<Float> transition;
    Transition<Float> transition1;
    Transition<Vector2> transition2;
    ScheduledTask a;


    public Leaf(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                GameObjectCollection gameObject, int seed ,Transition<Float> transition) {
        super(topLeftCorner, dimensions, renderable);
        this.topLeftCorner = topLeftCorner;
        this.dimensions = dimensions;
        this.renderable = renderable;
        this.gameObject = gameObject;
        this.transition = transition;
        this.seed = seed;
        random = new Random(seed);

        gameObject.addGameObject(this,Layer.STATIC_OBJECTS+2);
    }
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);

            this.transform().setVelocityY(0);
            setVelocity(Vector2.ZERO);
//            this.removeComponent(transition);



    }

    @Override
    public boolean shouldCollideWith(GameObject other) {
        super.shouldCollideWith(other);
        return other instanceof Block;
    }
}
