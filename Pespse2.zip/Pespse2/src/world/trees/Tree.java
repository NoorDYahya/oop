package world.trees;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.components.ScheduledTask;
import danogl.components.Transition;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import world.Block;
import world.Terrain;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;

public class Tree {
    private static final int HEIGHT = 5;
    private static final Color COLOR = new Color(100, 50, 20);
    private static final Color LEAVE_COLOR = new Color(50, 200, 30);
    private static final Color BASIC_SKY_COLOR = Color.decode("#80C6E5");
    Vector2 windowDimentions;
    GameObjectCollection gameObjects;
    Transition<Float> transition;
    Terrain terrain;
    Leaf leave;
    int groundLayer;
    Random rand;
    int seed;
    HashMap<Integer, Trunk> trunkhMap = new HashMap<>();
    HashMap<Integer, ArrayList<Leaf>> leafMap = new HashMap<>();
    public Tree(GameObjectCollection gameObjects, int groundLayer, Vector2 windowDimensions, int seed,
                Terrain terrain) {

        this.groundLayer = groundLayer;
        this.windowDimentions = windowDimensions;
        this.gameObjects = gameObjects;
        this.terrain = terrain;
        this.seed = seed;
//        rand = new Random(seed);

    }


    public void createInRange(int minX, int maxX) {

        for (int x = minX; x < maxX; x += Block.SIZE) {
            rand = new Random(Objects.hash(x, seed));
            double num = rand.nextInt(16);
            if (num == 0) {
                float y = terrain.groundHeightAt((float) num);
                Trunk trunk = new Trunk(new Vector2(x,  y +30 ),
                        new RectangleRenderable(COLOR));
                Vector2 topLeft = trunk.create(gameObjects);
                gameObjects.addGameObject(trunk, groundLayer);
                float topLeftCornerX = topLeft.x();
                ArrayList<Leaf> arrayList = new ArrayList<>();
                for (int i = 0; i < 150; i += Block.SIZE) {
                    for (int j = 0; j < 150; j += Block.SIZE) {

                        Leaf leaf = new Leaf(topLeft.subtract(new Vector2(2 * Block.SIZE, 0)), new Vector2(Block.SIZE,
                                Block.SIZE),
                                new RectangleRenderable(LEAVE_COLOR), gameObjects, seed, transition);
                        this.create(leaf);
                        topLeft = topLeft.add(new Vector2(Block.SIZE + 2, 0));
                        arrayList.add(leaf);
                    }
                    topLeft = new Vector2(topLeftCornerX, topLeft.y() + Block.SIZE + 2);
                }
                leafMap.put(x,arrayList);
                trunkhMap.put(x,trunk);


            }
        }
    }

    public void create(Leaf leaf) {
        float life = rand.nextFloat(5);
        float num = rand.nextFloat(30);
        Runnable run = new Runnable() {
            @Override
            public void run() {
                new Transition<Float>(
                        leaf, // the game object being changed
                        leaf.renderer()::setRenderableAngle, // the
                        // method to call
                        100f, // initial transition value
                        1000f, // final transition value
                        Transition.LINEAR_INTERPOLATOR_FLOAT, // use a cubic interpolator
                        life,
                        Transition.TransitionType.TRANSITION_BACK_AND_FORTH,
                        null);
//                new Transition<Vector2>(
//                        leaf, // the game object being changed
//                        leaf::setDimensions, // the
//                        // method to call
//                        leaf.getDimensions(), // initial transition value
//                        new Vector2(50, 60), // final transition value
//                        Transition.CUBIC_INTERPOLATOR_VECTOR, // use a cubic interpolator
//                        10,
//                        Transition.TransitionType.TRANSITION_BACK_AND_FORTH,
//                        null);

//                    leaf.transform().setVelocityY(20);
//                    leaf.renderer().fadeOut(30);

//                GameObject leaf1 = new Leaf(topLeftCorner, dimensions, renderable,gameObject,seed);
//                gameObject.addGameObject(leaf1, Layer.DEFAULT);
            }
        };
        Runnable run2 = new Runnable() {
            @Override
            public void run() {
                leaf.transform().setVelocityY(50);
                transition = new Transition<Float>(
                        leaf, // the game object being changed
                        leaf.transform()::setVelocityX, // the
                        // method to call
                        20f, // initial transition value
                        -20f, // final transition value
                        Transition.LINEAR_INTERPOLATOR_FLOAT, // use a cubic interpolator
                        5,
                        Transition.TransitionType.TRANSITION_BACK_AND_FORTH,
                        null);
                leaf.renderer().fadeOut(5, new Runnable() {
                    @Override
                    public void run() {
                        float deathTime = rand.nextFloat(15);
                        leaf.renderer().fadeOut(deathTime);
                        leaf.setCenter(leaf.topLeftCorner);
                        Leaf newLeaf = new Leaf(leaf.topLeftCorner, leaf.dimensions, leaf.renderable,
                                gameObjects, seed, transition);
                        gameObjects.removeGameObject(leaf, Layer.STATIC_OBJECTS + 2);
                        create(newLeaf);

                    }
                });

            }

        };

        new ScheduledTask(leaf, num, true, run);
        new ScheduledTask(leaf, life, false, run2);

    }

   public void removeInRange(int minX, int maxX){
       for (Integer i : trunkhMap.keySet()) {
           if (i< minX || i > maxX) {
               gameObjects.removeGameObject(trunkhMap.get(i),Layer.BACKGROUND);
               for (Leaf leaf : leafMap.get(i)) {

                   gameObjects.removeGameObject(leaf,Layer.STATIC_OBJECTS+2);

               }
               System.out.println("x="+i);


           }
       }

   }
}
