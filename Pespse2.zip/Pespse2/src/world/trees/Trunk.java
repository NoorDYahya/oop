package world.trees;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import world.Block;
import world.Terrain;

import java.awt.*;
import java.util.Random;


public class Trunk extends Block {
    private static final int HEIGHT = 10;
    Vector2 topLeftCorner;
    private Vector2 dimensions;
    Renderable renderable;
    public Trunk(Vector2 topLeftCorner, Renderable renderable) {
        super(topLeftCorner, renderable);
        this.topLeftCorner = topLeftCorner;
        this.renderable = renderable;


    }

    public Vector2 create(GameObjectCollection gameObjectCollection){
        for (int z = 0 ; z < HEIGHT ; z++)
        {
           GameObject block = new Block(topLeftCorner,renderable);
           topLeftCorner = topLeftCorner.subtract(new Vector2(0,Block.SIZE));
           gameObjectCollection.addGameObject(block);


        }
        return topLeftCorner;
    }

}
