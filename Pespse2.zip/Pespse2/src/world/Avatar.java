package world;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.components.CoordinateSpace;
import danogl.gui.ImageReader;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.AnimationRenderable;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import world.trees.Trunk;

import javax.swing.text.TabExpander;
import java.awt.*;
import java.awt.event.KeyEvent;

public class Avatar extends GameObject {
    static Vector2 dimensions;
    private static GameObjectCollection gameObjects;
    private static int layer;
    private static UserInputListener inputListener;
    private static ImageReader imageReader;
    private static AnimationRenderable animationFly;
    private static AnimationRenderable animationSide;
    private static AnimationRenderable animationUp;
    Vector2 topLeftCorner;
    Renderable renderable;
    final float AVATAR_SPEED = 400;
    final float GRAVITY = 300;
    float energy;
    TextRenderable textRenderable;


    public Avatar(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable, GameObjectCollection
            gameObjectCollection) {
        super(topLeftCorner, dimensions, renderable);
        Avatar.dimensions = dimensions;
        this.topLeftCorner = topLeftCorner;
        this.renderable = renderable;
        energy = 100;
        textRenderable = new TextRenderable(String.format("Energy: " + energy));
        textRenderable.setString(String.format("Energy: " + energy));

        this.renderer().setRenderable(textRenderable);

        GameObject text = new GameObject(new Vector2(10, 15), dimensions, textRenderable);
        text.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        gameObjectCollection.addGameObject(text, Layer.BACKGROUND);
        animationFly = new AnimationRenderable(new String[]{"src/Old hero fly 1.png"
                , "src/Old hero fly 2.png","src/Old hero fly 3.png","src/Old hero fly 4.png","src/Old hero " +
                "fly 5.png","src/Old hero fly 6.png"},
                imageReader,
                true, 0);
        animationSide = new AnimationRenderable(new String[]{"src/Old hero left 2.png", "src/Old hero left 1.png"
                , "src/Old hero left 3.png", "src/Old hero left 4.png", "src/Old hero left 5.png"},
                imageReader,
                true, 0);

        animationUp = new AnimationRenderable(new String[]{"src/Old hero" +
                ".png", "src/Old hero idle.png", "src/Old hero0.png"},
                imageReader,
                true, 0);


    }

    public static Avatar create(GameObjectCollection gameObjects,
                                int layer, Vector2 topLeftCorner,
                                UserInputListener inputListener,
                                ImageReader imageReader) {


        Avatar.gameObjects = gameObjects;
        Avatar.layer = layer;
        Avatar.inputListener = inputListener;
        Avatar.imageReader = imageReader;


        Renderable renderable = imageReader.readImage("src/Old hero idle.png", true);
        Avatar avatar = new Avatar(topLeftCorner.subtract(new Vector2(0, Block.SIZE)), new Vector2(60, 60),
                renderable, gameObjects);
        avatar.physics().preventIntersectionsFromDirection(Vector2.ZERO);


        return avatar;


    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        renderer().setRenderable(renderable);
        transform().setAccelerationY(GRAVITY);
        if(transform().getVelocity().y() == 300){
            transform().setVelocityY(300);
        }
        Vector2 moveDirection = Vector2.ZERO;


        if (inputListener.isKeyPressed(KeyEvent.VK_LEFT)) {

            moveDirection = moveDirection.add(Vector2.LEFT);
            transform().setVelocityX(-1 * AVATAR_SPEED);
            renderer().setIsFlippedHorizontally(true);
            renderer().setRenderable(animationSide);
        }
        if (inputListener.isKeyPressed(KeyEvent.VK_RIGHT)) {

            moveDirection = moveDirection.add(Vector2.RIGHT);
            transform().setVelocityX(AVATAR_SPEED);
            renderer().setIsFlippedHorizontally(false);
            renderer().setRenderable(animationSide);

        }
        if (inputListener.isKeyPressed(KeyEvent.VK_SPACE) && getVelocity().y() == 0) {

            moveDirection = moveDirection.add(Vector2.UP);
            transform().setVelocityY(-1 * AVATAR_SPEED);
            renderer().setRenderable(animationUp);

        }
        if (inputListener.isKeyPressed(KeyEvent.VK_SPACE) && inputListener.isKeyPressed(KeyEvent.VK_SHIFT) && energy > 0) {

            energy -= 0.5;
            textRenderable.setString(String.format("Energy: " + energy));
            if (energy == 0) {
                transform().setVelocityY((float) (0.5 * GRAVITY));
            }
            else
            {
                transform().setAccelerationY(-1 * 100);
            }
            renderer().setRenderable(animationFly);

        }
        if (energy < 100 && transform().getVelocity().y() == 0) {
            energy += 0.5;
            textRenderable.setString(String.format("Energy: " + energy));

        }




    }

    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        transform().setVelocity(Vector2.ZERO);
        transform().setAccelerationY(0);
//            this.removeComponent(transition);


    }

    @Override
    public boolean shouldCollideWith(GameObject other) {
        super.shouldCollideWith(other);
        return other instanceof Block;
    }
}
