package world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import pepse.util.ColorSupplier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

import java.awt.*;

public class Terrain {
    private static final Color BASE_GROUND_COLOR = new Color(212, 123, 74);
    private static final int TERRAIN_DEPTH = 100;
    HashSet<Integer> hashSet = new HashSet<Integer>();
    HashMap<Integer, ArrayList<Block>> hashMap = new HashMap<>();
    GameObjectCollection gameObjects;
    int groundLayer;
    float groundHeightAtX0;
    int seed;
    Vector2 windowDimensions;
    Random random;

    public Terrain(GameObjectCollection gameObjects,
                   int groundLayer, Vector2 windowDimensions,
                   int seed) {
        this.gameObjects = gameObjects;
        this.groundLayer = groundLayer;
        this.seed = seed;
        this.windowDimensions = windowDimensions;
        random = new Random(seed);

    }

    public float groundHeightAt(float x) {
//        NoiseGenerator noise = new NoiseGenerator(seed);
//
//        float value = 0;
//        float size = noise.default_size;
//        float initialSize = size;
//
//        while (size >= 1) {
//            value += noise.smoothNoise((x / size), (0f / size), (0f / size)) * size;
//            size /= 2.0;
//        }
//
//        return windowDimensions.y() / 2 - (value / size);
//        float y = (float) Math.sin(x);
//        y = Math.abs(y);
//        float n = y * windowDimensions.x() /Block.SIZE;
//        float res = (y * windowDimensions.x() /Block.SIZE) % Block.SIZE;
//        return n+res;
        return 2*windowDimensions.y()/3;

    }

    private static class NoiseGenerator {
        private int[] permutation;
        private final int seed;
        private long default_size;
        private int[] p;

        public NoiseGenerator(int seed) {
            this.seed = (int) (new Random(seed).nextGaussian() * 255);
            init();
        }

        private void init() {
            // Initialize the permutation array.
            this.p = new int[512];
            this.permutation = new int[]{151, 160, 137, 91, 90, 15, 131, 13, 201,
                    95, 96, 53, 194, 233, 7, 225, 140, 36, 103, 30, 69, 142, 8, 99,
                    37, 240, 21, 10, 23, 190, 6, 148, 247, 120, 234, 75, 0, 26,
                    197, 62, 94, 252, 219, 203, 117, 35, 11, 32, 57, 177, 33, 88,
                    237, 149, 56, 87, 174, 20, 125, 136, 171, 168, 68, 175, 74,
                    165, 71, 134, 139, 48, 27, 166, 77, 146, 158, 231, 83, 111,
                    229, 122, 60, 211, 133, 230, 220, 105, 92, 41, 55, 46, 245, 40,
                    244, 102, 143, 54, 65, 25, 63, 161, 1, 216, 80, 73, 209, 76,
                    132, 187, 208, 89, 18, 169, 200, 196, 135, 130, 116, 188, 159,
                    86, 164, 100, 109, 198, 173, 186, 3, 64, 52, 217, 226, 250,
                    124, 123, 5, 202, 38, 147, 118, 126, 255, 82, 85, 212, 207,
                    206, 59, 227, 47, 16, 58, 17, 182, 189, 28, 42, 223, 183, 170,
                    213, 119, 248, 152, 2, 44, 154, 163, 70, 221, 153, 101, 155,
                    167, 43, 172, 9, 129, 22, 39, 253, 19, 98, 108, 110, 79, 113,
                    224, 232, 178, 185, 112, 104, 218, 246, 97, 228, 251, 34, 242,
                    193, 238, 210, 144, 12, 191, 179, 162, 241, 81, 51, 145, 235,
                    249, 14, 239, 107, 49, 192, 214, 31, 181, 199, 106, 157, 184,
                    84, 204, 176, 115, 121, 50, 45, 127, 4, 150, 254, 138, 236,
                    205, 93, 222, 114, 67, 29, 24, 72, 243, 141, 128, 195, 78, 66,
                    215, 61, 156, 180};
            this.default_size = 35;

            // Populate it
            for (int i = 0; i < 256; i++) {
                p[256 + i] = p[i] = permutation[i];
            }

        }


        public float smoothNoise(float x, float y, float z) {
            // Offset each coordinate by the seed value
            x += this.seed;
            y += this.seed;
            x += this.seed;

            int X = (int) Math.floor(x) & 255; // FIND UNIT CUBE THAT
            int Y = (int) Math.floor(y) & 255; // CONTAINS POINT.
            int Z = (int) Math.floor(z) & 255;

            x -= Math.floor(x); // FIND RELATIVE X,Y,Z
            y -= Math.floor(y); // OF POINT IN CUBE.
            z -= Math.floor(z);

            float u = fade(x); // COMPUTE FADE CURVES
            float v = fade(y); // FOR EACH OF X,Y,Z.
            float w = fade(z);

            int A = p[X] + Y;
            int AA = p[A] + Z;
            int AB = p[A + 1] + Z; // HASH COORDINATES OF
            int B = p[X + 1] + Y;
            int BA = p[B] + Z;
            int BB = p[B + 1] + Z; // THE 8 CUBE CORNERS,

            return lerp(w, lerp(v, lerp(u, grad(p[AA], x, y, z),    // AND ADD
                                    grad(p[BA], x - 1, y, z)), // BLENDED
                            lerp(u, grad(p[AB], x, y - 1, z),    // RESULTS
                                    grad(p[BB], x - 1, y - 1, z))),// FROM 8
                    lerp(v, lerp(u, grad(p[AA + 1], x, y, z - 1),    // CORNERS
                                    grad(p[BA + 1], x - 1, y, z - 1)), // OF CUBE
                            lerp(u, grad(p[AB + 1], x, y - 1, z - 1),
                                    grad(p[BB + 1], x - 1, y - 1, z - 1))));
        }

        private float fade(float t) {
            return t * t * t * (t * (t * 6 - 15) + 10);
        }

        private float lerp(float t, float a, float b) {
            return a + t * (b - a);
        }

        private float grad(int hash, float x, float y, float z) {
            int h = hash & 15; // CONVERT LO 4 BITS OF HASH CODE
            float u = h < 8 ? x : y, // INTO 12 GRADIENT DIRECTIONS.
                    v = h < 4 ? y : h == 12 || h == 14 ? x : z;
            return (float) (((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v));
        }

    }


    public void createInRange(int minX, int maxX) {

        if (minX % Block.SIZE != 0) {
            int per = minX % Block.SIZE;
            minX -= per;
        }

        for (int i = minX; i < maxX; i += Block.SIZE) {

            ArrayList<Block> arr = new ArrayList<>();
            float y = groundHeightAt(i);
            for (int j = 0; j < TERRAIN_DEPTH; j++) {

                Block block = new Block(new Vector2(i, y),
                        new RectangleRenderable(ColorSupplier.approximateColor(BASE_GROUND_COLOR)));
                y += Block.SIZE;
                block.setTag("ground");
                arr.add(block);
                if(j == 0 || j==1){
                    gameObjects.addGameObject(block, groundLayer);
                }
                else
                {
                    gameObjects.addGameObject(block, groundLayer -10);
                }

            }
            hashMap.put(i, arr);

        }


    }

    public void removeInRange(int minX, int maxX) {
        {
            for (Integer i : hashMap.keySet()) {
                if (i< minX || i > maxX) {
                    int counter = 0;
                    for (Block item : hashMap.get(i)) {
                        if(counter ==0 || counter == 1)
                        {
                            gameObjects.removeGameObject(item,groundLayer);
                        }
                        else{
                            gameObjects.removeGameObject(item,groundLayer-10);
                        }
                        counter++;

                    }
                    System.out.println("x="+i);


                }
            }
        }

    }


}
