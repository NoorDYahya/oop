package world.daynight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.gui.rendering.OvalRenderable;
import danogl.util.Vector2;

import java.awt.*;

public class SunHalo {

    public static GameObject create(
            GameObjectCollection gameObjects,
            GameObject sun,
            Color color,
            int layer){
        GameObject halo = new GameObject(Vector2.ZERO,new Vector2(200,200),new OvalRenderable(color));
        halo.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        halo.setTag("halo");
        gameObjects.addGameObject(halo,layer);
        danogl.components.Component com = deltaTime -> halo.setCenter(sun.getCenter());
        halo.addComponent(com);
        return halo;
    }



}
