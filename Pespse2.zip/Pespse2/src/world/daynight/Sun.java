package world.daynight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.components.Transition;
import danogl.gui.rendering.OvalRenderable;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

import java.awt.*;
import java.util.function.Consumer;

public class Sun extends GameObject {
    private static Vector2 windowDimention;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     *                      the GameObject will not be rendered.
     */
    public Sun(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable) {
        super(topLeftCorner, dimensions, renderable);
    }

    public static GameObject create(
            GameObjectCollection gameObjects,
            int layer,
            Vector2 windowDimensions,
            float cycleLength) {
        windowDimention = windowDimensions;
        GameObject sun = new GameObject(new Vector2(windowDimensions.x() / 2, windowDimensions.y()/2),
                new Vector2(100,100),
                new OvalRenderable(Color.yellow));
        sun.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        sun.setTag("sun");
        gameObjects.addGameObject(sun, layer);
        java.util.function.Consumer<Float> method = (Float angleInSky) -> sun.setCenter(calcSunPosition(windowDimention,
                angleInSky) );
        new Transition<Float>(
                sun, // the game object being changed
                 method, // the
                // method to call
                0f, // initial transition value
                360f, // final transition value
                Transition.LINEAR_INTERPOLATOR_FLOAT, // use a cubic interpolator
                cycleLength,
                Transition.TransitionType.TRANSITION_LOOP,
                null);

        return sun;
    }

    private static Vector2 calcSunPosition(Vector2 windowDimensions,
                                    float angleInSky) {
        return new Vector2((float) (windowDimensions.x() / 2 - ((windowDimensions.x() / 4) * Math.cos(angleInSky))),
                (float)(windowDimensions.y() / 2 -(windowDimensions.x() / 4 * Math.sin(angleInSky))));
    }
}
