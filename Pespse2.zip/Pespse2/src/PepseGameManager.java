import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import world.Avatar;
import world.Block;
import world.Sky;
import world.Terrain;
import world.daynight.Night;
import world.daynight.Sun;
import world.daynight.SunHalo;
import world.trees.Tree;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

public class PepseGameManager extends GameManager {
    private static final Color HALO_COLOR = new Color(255, 255, 0, 20);
    Vector2 windowDimention;
    Avatar avatar;
    int maxX;
    int minX;
    Terrain terrain;
    HashSet<Integer> hashSet = new HashSet<Integer>();
    Tree tree;

    public static void main(String[] args) {
        new PepseGameManager().run();
    }

    @Override
    public void initializeGame(ImageReader imageReader, SoundReader soundReader,
                               UserInputListener inputListener,
                               WindowController windowController) {
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        windowDimention = windowController.getWindowDimensions();
        windowController.setTargetFramerate(50);
        //SKY
        Sky.create(gameObjects(), windowDimention, Layer.BACKGROUND);
        terrain = new Terrain(gameObjects(), Layer.STATIC_OBJECTS, windowDimention, 2);
        maxX = (int) ((int) windowDimention.x() + 0.4*windowDimention.x());
        minX = (int) (-0.3*windowDimention.x());
        terrain.createInRange((int) (-0.25 * windowDimention.x()), maxX + (int) (-0.25 * windowDimention.x()));

        Night.create(gameObjects(), Layer.FOREGROUND, windowDimention, 20);
        GameObject sun = Sun.create(gameObjects(), Layer.BACKGROUND, windowDimention,
                900);
        SunHalo.create(gameObjects(), sun, HALO_COLOR, Layer.BACKGROUND + 10);
        tree = new Tree(gameObjects(), Layer.BACKGROUND, windowDimention, 4, terrain);
        tree.createInRange(0, (int) windowDimention.x());
        gameObjects().layers().shouldLayersCollide(Layer.STATIC_OBJECTS + 2, Layer.STATIC_OBJECTS,
                true);
        Vector2 initialAvatarLocation = new Vector2(100, terrain.groundHeightAt(100) - Block.SIZE);
        avatar = Avatar.create(gameObjects(), Layer.DEFAULT, initialAvatarLocation
                , inputListener, imageReader);
        Vector2 location = windowController.getWindowDimensions().mult(0.5f).subtract(initialAvatarLocation);
        setCamera(new Camera(avatar, Vector2.ZERO,
                windowController.getWindowDimensions(),
                windowController.getWindowDimensions()));
        gameObjects().addGameObject(avatar);

    }


    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        Vector2 cameraVector = getCamera().getTopLeftCorner();
        if (cameraVector.x() < minX) {
            System.out.println("left");
            minX = (int) (cameraVector.x() -0.1*windowDimention.x() );
            maxX = (int) ((int) avatar.getCenter().x() -0.3*windowDimention.x());


            terrain.createInRange(minX,maxX);
            terrain.removeInRange((int) cameraVector.x()-180,
                    (int) (cameraVector.x() + windowDimention.x()+180));
            tree.createInRange(minX,maxX);
            tree.removeInRange((int) cameraVector.x()-180,
                    (int) (cameraVector.x() + windowDimention.x()+180));

        }
        if (cameraVector.x() >maxX) {

            minX = (int) (maxX +0.1*windowDimention.x());

            maxX = (int) (cameraVector.x() + 2*windowDimention.x());

            terrain.createInRange(minX, maxX);
            terrain.removeInRange((int) cameraVector.x()-60,
                    (int) (cameraVector.x() + windowDimention.x()+60));
            tree.createInRange(minX,maxX);
            tree.removeInRange((int) cameraVector.x()-60,
                    (int) (cameraVector.x() + windowDimention.x()+60));

        }


    }
}