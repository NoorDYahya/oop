
import java.util.*;

public class WhateverPlayer implements Player{
    Random rand = new Random();

    @Override
    /**
     * strategy: this player  will choose randomly an indexes of a cell and if its valid the played will
     * put mark in else it will try till it found a valid one .
     * @param board
     * @param mark the player mark
     */
    public void playTurn(Board board, Mark mark) {

        int row = rand.nextInt(board.size);
        int cul = rand.nextInt(board.size);
        while(!board.putMark(mark, row, cul)){
            System.out.println("Invalid coordinates, try again: ");
            row = rand.nextInt(board.size);
            cul = rand.nextInt(board.size);

        }
    }
}
