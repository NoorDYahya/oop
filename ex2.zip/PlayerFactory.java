public class PlayerFactory {
    Player buildPlayer(String arg){
          Player player = null;
          String lowerString = arg.toLowerCase();
          switch (lowerString){
              case "human":
                  player = new HumanPlayer();
                  break;
              case "clever":
                  player = new CleverPlayer();
                  break;
              case "whatever":
                  player = new WhateverPlayer();
                  break;
              case "genius":
                  player = new GeniusPlayer();
                  break;

          }
          return player;
    }
}
