public enum Mark {
    BLANK,O,X
}
