public class RendererFactory {
      int size ;
// the factory shift between the two valid renders (console and none)

    /**
     * the function get the type of the render and build it according to the matching constructor
     * @param arg
     * @param size
     * @return the builded new render
     */
      Renderer buildRenderer(String arg, int size){
          this.size = size;
          Renderer render = null;
          switch (arg){
              case"console":
                  render = new ConsoleRenderer(size);
                  break;
              case"none":
                  render = new VoidRenderer();
                  break;
          }
          return render;
      }

}
