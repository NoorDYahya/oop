public class Board {

    public static final int SIZE = 4;
    public static final int WIN_STREAK = 3;
    private static Mark currentPlayer;
    int counter = 0;
    int aviableCell = SIZE * SIZE;
    int cul, row;
    int size;
    Mark[][] board;

    /**
     * default constructor that  build a board with default size = 16 and initialize the board with blank
     * cells
     */
    public Board() {
        this.size = SIZE;
        board = new Mark[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                board[i][j] = Mark.BLANK;
            }
        }

    }
    /**
     * default constructor that  build a board with the given size  and initialize the board with blank
     * cells
     */
    Board(int size){
        this.size = size;
        board = new Mark[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                board[i][j] = Mark.BLANK;
            }
        }
    }

    /**
     * this function will put mark in the given indexes of the cell  on the board
     * @param mark mark to put on
     * @param i index of the row
     * @param j index of the col
     * @return true if the  cell is valid else false
     */
    public boolean putMark(Mark mark, int i, int j) {
        if (i >= size|| j >= size || i < 0 || j < 0 || board[i][j] != Mark.BLANK) {
            return false;
        }
        board[i][j] = mark;
        aviableCell -= 1;
        cul = j;
        row = i;
        currentPlayer = mark;
        return true;
    }

    /**
     * getter function of the mark in the desired cell
     * @param i index of the row
     * @param j index of  the col
     * @return return the mark in the desired cell if the cell exist
     */
    public Mark getMark(int i, int j) {
        if (i >= size|| j >= size|| i < 0 || j < 0) {
            return Mark.BLANK;
        }
        return board[i][j];
    }

    /**
     * @return return the board size
     */
    public int getSize(){
        return size;
    }
    /**
     * @return return the board
     */
    public Mark[][] getBoard(){
        return board;
    }


}

