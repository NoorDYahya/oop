public interface Renderer {
    void renderBoard(Board board);
}
