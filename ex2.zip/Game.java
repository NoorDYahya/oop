
public class Game {
    Player playerX;
    Player playerO;
    Mark currentPlayer;
    Renderer renderer;
    int aviableCell;
    Board board ;
    int winStreak = 3;
    int size = 4;

    /**
     * constructor that get two players and renderer and build/initialize  the board of the game
     * @param playerX
     * @param playerO
     * @param renderer
     */
    public Game(Player playerX, Player playerO, Renderer renderer) {
        this.playerX = playerX;
        this.playerO = playerO;
        this.renderer = renderer;
        board = new Board();

    }
    /**
     * constructor that get two players ,renderer size , win streak build/initialize  the board wuth the
     * given size  and check the validity of the winstreak (1<=winstreak <= size)

     * @param playerX
     * @param playerO
     * @param renderer
     */
    public Game(Player playerX, Player playerO, int size, int winStreak, Renderer renderer){
        this.playerX = playerX;
        this.playerO = playerO;
        this.renderer = renderer;
        this.size = size;
        board = new Board(size);
        if(winStreak > size || winStreak < 1){
            this.winStreak = size;
        }
        else{
            this.winStreak = winStreak;
        }
    }

    /**
     *
     * @return return the win streak
     */
    public int getWinStreak(){
        return this.winStreak;
    }

    /**
     *
     * @return return true if the there is a winner or if there is no more aviable celss in the board
     */
    private boolean gameEnded() {
        return aviableCell == 0 || getWinner(board,currentPlayer) != Mark.BLANK;
    }


    /**
     * this function will check for winstreak in all posiible direction and return the mark than completed
     * a winstreak
     * @param board board to check in
     * @param mark  the mark that complete a win streak
     * @return mark if there is a winner else return blank
     *
     */
    private Mark getWinner(Board board, Mark mark) {
        int row = 0, col = 0, i = 0;


        for ( row = 0; row < board.getSize(); row++)             // This first for loop checks every row
        {
            for ( col = 0; col < (board.getSize()-(winStreak-1)); col++)
                // And all columns until N away from the end
            {
                while (board.getMark(row,col) == mark)
                    // For consecutive rows of the current player's mark
                {
                    col++;
                    i++;
                    if (i == winStreak)
                    {
                        return mark;
                    }
                }
                i = 0;
            }
        }

        for ( col = 0; col < board.getSize(); col++)     // This one checks for columns of consecutive marks
        {
            for ( row = 0; row < (board.getSize()-(winStreak-1)); row++)
            {
                while (board.getMark(row,col) == mark)
                {
                    row++;
                    i++;
                    if (i == winStreak)
                    {
                        return mark;
                    }
                }
                i = 0;
            }
        }

        for ( col = 0; col < (board.getSize() - (winStreak-1)); col++)
            // This one checks for "forwards" diagonal runs
        {
            for ( row = 0; row < (board.getSize()-(winStreak-1)); row++)
            {
                while (board.getMark(row,col)== mark)
                {
                    row++;
                    col++;
                    i++;
                    if (i == winStreak)
                    {
                        return mark;
                    }
                }
                i = 0;
            }
        }
        // Finally, the backwards diagonals:
        for ( col = board.getSize()-1; col > 0; col--)
            // Start from the last column and go until
            // N columns from the first
        {
            // The math seems strange here but the numbers work out when you trace them
            for ( row = 0; row < (board.getSize()-(winStreak-1)); row++)
                // Start from the first row and go until N rows from the last
            {
                while (board.getMark(row,col) == mark)
                    // If the current player's character is there
                {
                    row++;                                  // Go down a row
                    col--;                                  // And back a column
                    i++;         // The i variable tracks how many consecutive marks have been found
                    if (i == winStreak)                             // Once i == N
                    {
                        return mark;         // Return the current player number to the
                    }                     // winnner variable in the playGame function
                }          // If it breaks out of the while loop, there weren't N consecutive marks
                i = 0;                    // So make i = 0 again
            }         // And go back into the for loop, incrementing the row to check from
        }

        return Mark.BLANK;


    }

    /**
     *  run is a function that run the game betweaan two players for one round , the function renderer the
     *  board in the screen after every turn
     * @return the winner if existed
     */
    public Mark run() {
        int counter = 0;
//        Player[] players = { playerX, playerO };
        Mark[] marks = {Mark.X, Mark.O};
        aviableCell = board.getSize()*board.getSize();
        while (!gameEnded()) {
            renderer.renderBoard(board);
            if (counter % 2 == 0) {  //shift the turn betwean two players
                this.playerX.playTurn(board, marks[0]);
                currentPlayer = marks[0];

            } else {
                this.playerO.playTurn(board, marks[1]);
                currentPlayer = marks[1];
            }
            aviableCell--;
            counter += 1;
        }
        renderer.renderBoard(board);
        return getWinner(board,currentPlayer);

    }

}
