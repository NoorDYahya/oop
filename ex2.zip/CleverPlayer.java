import java.util.Random;

public class CleverPlayer implements Player {
    int size;
    Board board;

    /**
     * this function will return the maximum between 8 values
     * @param a
     * @param b
     * @param c
     * @param d
     * @param e
     * @param f
     * @param g
     * @param h
     * @return
     */
    private static int max(int a, int b, int c, int d, int e, int f, int g, int h) {

        int max = a;

        if (b > max)
            max = b;
        if (c > max)
            max = c;
        if (d > max)
            max = d;
        if (e > max) {
            max = e;
        }
        if (f > max) {
            max = f;
        }
        if (g >max) {
            max = g;
        }
        if (h > max) {
            max = h;
        }

        return max;
    }

    /**
     * this function will count the number of the apperence of the mark in all directions of the given
     * indexes   as long as the appearance of the marks is consecutive and return this count including the
     * given cell
     * @param row
     * @param col
     * @param rowDelta
     * @param colDelta
     * @param mark
     * @return
     */
    private int countMarkInDirection(int row, int col, int rowDelta, int colDelta, Mark mark) {
        int count = 0;

        while (row < size && row >= 0 && col < size && col >= 0 && board.getMark(row, col) == mark) {
            count++;
            row += rowDelta;
            col += colDelta;
        }
        return count;
    }

    /**
     * strategy: this player start his turn with put mark in the centered cell if its avaiable and then in
     * every new turn , randomly choose a cell that marked with tha same current player mark and coount the
     * number of the marks in every possible direction ,if there is a max count of marks in one direction
     * the player will add mark in this direction in order to make the count close to the winstreak value
     * else it will put mark in random way
     * @param board
     * @param mark the player mark
     */
    @Override
    public void playTurn(Board board, Mark mark) {
        this.board = board;
        size = board.getSize();
        Random rand = new Random();
//        int centerI = Math.abs(board.getSize() / 2) - 1;
//        int centerJ = Math.abs(board.getSize() / 2) - 1;
        int centerI = 0;
        int centerJ = 0;
        if (board.getMark(centerI, centerJ) == Mark.BLANK) {
            board.putMark(mark, centerI, centerJ);
        } else {

            int row = centerI;
            int cul = centerJ;
            if (board.getMark(row, cul) != mark) {
                row = rand.nextInt(board.size);
                cul = rand.nextInt(board.size);
            }
            // count the marks in every possible direction
            int right = countMarkInDirection(row, cul, 0, 1, mark);
            int left = countMarkInDirection(row, cul, 0, -1, mark);

            int up = countMarkInDirection(row, cul, -1, 0, mark);
            int down = countMarkInDirection(row, cul, 1, 0, mark);

            int diagonalUp = countMarkInDirection(row, cul, -1, 1, mark);
            int diagonalDown = countMarkInDirection(row, cul, 1, -1, mark);

            int shiftedDiagonalUp = countMarkInDirection(row, cul, -1, -1, mark);
            int shiftedDiagonalDown = countMarkInDirection(row, cul, 1, 1, mark);

            int max = max(left, right, up, down, diagonalDown, diagonalUp, shiftedDiagonalUp,
                    shiftedDiagonalDown);
            // check for the maximum and if exist add mark in the direction by adding the count of the
            // appearance of the marks to the last modified mark
            if (max == right && max >0) { //max>1
                if (board.getMark(row, cul + right) == Mark.BLANK && (cul + right) < size) {
                    row = row;
                    cul = cul + right;
                    board.putMark(mark, row, cul);

                }

            }
            else if  (max == left && max >1) { //max>1
                if (board.getMark(row, cul - left) == Mark.BLANK && (cul - left) >= 0) {
                    row = row;
                    cul = cul - left;
                    board.putMark(mark, row, cul);
                }

            }
            else if (max == up && max >1) { //max>1
                if (board.getMark(row - up, cul) == Mark.BLANK && (row - up) >= 0) {
                    row = row - up;
                    cul = cul;
                    board.putMark(mark, row, cul);
                }

            }
            else if (max == down && max >1) { //max>1
                if (board.getMark(row + down, cul) == Mark.BLANK && (row + down) < size) {
                    row = row + down;
                    cul = cul;
                    board.putMark(mark, row, cul);
                }

            }
            else if (max == diagonalUp && max >1) { //max>1
                if (board.getMark(row - diagonalUp, cul + diagonalUp) == Mark.BLANK && (row - diagonalUp)
                        >= 0 && (cul + diagonalUp) < size) {
                    row = row + diagonalUp;
                    cul = cul + diagonalUp;
                    board.putMark(mark, row, cul);
                }

            }
            else if (max == diagonalDown && max >1) { //max>1
                if (board.getMark(row + diagonalDown, cul - diagonalDown) == Mark.BLANK &&
                        (cul - diagonalDown) >= 0 && (row + diagonalDown) < size) {
                    row = row + diagonalDown;
                    cul = cul - diagonalDown;
                    board.putMark(mark, row, cul);

                }

            }
            else if (max == shiftedDiagonalUp && max >1) { //max>1
                if (board.getMark(row - shiftedDiagonalUp, cul - shiftedDiagonalUp) == Mark.BLANK && (cul - shiftedDiagonalUp) >=
                        0 && (row - shiftedDiagonalUp) >= 0) {
                    row = row - shiftedDiagonalUp;
                    cul = cul - shiftedDiagonalUp;
                    board.putMark(mark, row, cul);

                }

            }
            else if (max == shiftedDiagonalDown && max >1) { //max>1
                if (board.getMark(row + shiftedDiagonalDown, cul + shiftedDiagonalDown) == Mark.BLANK
                        && (cul + shiftedDiagonalDown) <
                        size && (row + shiftedDiagonalDown) < size) {
                    row = row + shiftedDiagonalDown;
                    cul = cul + shiftedDiagonalDown;
                    board.putMark(mark, row, cul);

                }

            } else {
                row = rand.nextInt(board.size);
                cul = rand.nextInt(board.size);
                while (!board.putMark(mark, row, cul)) {
                    row = rand.nextInt(board.size);
                    cul = rand.nextInt(board.size);
                }
            }

        }


    }
}


