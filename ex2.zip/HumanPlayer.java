import java.util.Scanner;

public class HumanPlayer implements Player {
    @Override
    /**
     * human player: this function in every turn  will ask the user for input of the cell indexes on order
     * to matk it
     */
    public void playTurn(Board board, Mark mark) {
        Scanner in = new Scanner(System.in);
        System.out.println("Player "+ mark +", type coordinates: ");
        int num = in.nextInt();
        int cul = num % 10 ;
        int row = num / 10 ;
        // ask the user for indexes till it is valid
        while (row >= board.getSize() || cul >= board.getSize() || row < 0 || cul < 0 ) {

            System.out.println("Invalid coordinates, type again: ");
            in = new Scanner(System.in);
            num = in.nextInt();
            cul = num % 10 ;
            row= num / 10 ;
        }
        // ask for new indexes if the putmark function failed to put mark because of already filled cell
        while(!board.putMark(mark, row, cul)){
            System.out.println("Invalid coordinates, type again: ");
            in = new Scanner(System.in);
            num = in.nextInt();
            cul = num % 10 ;
            row= num / 10 ;
        }
    }


}
