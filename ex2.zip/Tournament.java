public class Tournament {
    int rounds ;
    Renderer renderer;
    Player[] players;
    int[] playersScore = {0,0};
    int size ;
    int winStreak;
    String[] playerNames;
    int count =0;
    int ties = 0;

    /**
     * Tournament constructor that construct that get :
     * @param rounds number of the round of the current game
     * @param renderer the desire render (none/console)
     * @param players players array
     */
    Tournament(int rounds, Renderer renderer , Player[] players){
           this.rounds = rounds;
           this.renderer = renderer;
           this.players = new Player[players.length];
           for(int i = 0 ; i < players.length ; i++){
               this.players[i] = players[i];
           }
    }

    /**
     * The function manage the whole game between the players , based on the specified round .
     * In every round the function should shift the marks between the players such that the  one that
     * played x in the previes round will play as O in the next one .
     * After every game the function print the result with specific text that show the number of the
     * winning rounds of each player number of the ties ones as well.
     * @param size The board's size
     * @param winStreak
     * @param playerNames the players name (clever or genius or human or whatever)
     */
    void playTournament(int size, int winStreak, String[] playerNames){
        this.size = size;
        this.winStreak = winStreak;
        this.playerNames= new String[playerNames.length]; //copy the input array of players name
        for(int i = 0 ; i < playerNames.length ; i++){
            this.playerNames[i] = playerNames[i];
        }

        int indexXplayer = 0; // index in order to shift the marks
        while(count != rounds){

            Game game = new Game(players[indexXplayer],players[1-indexXplayer],renderer);
            Mark winner = game.run();
            if(winner == Mark.X){
                playersScore[indexXplayer]+=1;
            }
            else if(winner == Mark.O){
                playersScore[1-indexXplayer]+=1;
            }
            else{
                ties +=1;
            }
            count++;
            indexXplayer = 1- indexXplayer;
        }
        System.out.println("######### Results #########");
        System.out.println("Player 1, "+playerNames[0]+" won:" +playersScore[0]+" rounds");
        System.out.println("Player 2, "+playerNames[1]+" won:" +playersScore[1]+" rounds");
        System.out.println("Ties: "+ ties);
    }
    public static void main(String[] args) {

        String arg4 = (args[4].toLowerCase());
        String arg5 = (args[5].toLowerCase());
        if (!(arg4.equals("clever") ||arg4.equals("genius")
                ||arg4.equals("human") ||arg4.equals("whatever")) || !(arg5.equals("clever")||arg5.equals(
                        "genius")
                ||arg5.equals("human") ||arg5.equals("whatever"))){
            System.out.println("Choose a player, and start again");
            System.out.println("The players:[human, clever, whatever, genius]");
            return;
        }
        RendererFactory rendered = new RendererFactory();
        PlayerFactory player = new PlayerFactory();
        Renderer render  = rendered.buildRenderer(args[3],Integer.parseInt(args[1]));
        Player player1 = player.buildPlayer(args[4]);
        Player player2 = player.buildPlayer(args[5]);
        Player[] players = {player1,player2};
        String[] playerNames = new String[2];
        playerNames[0] = args[4];
        playerNames[1] = args[5];
        Tournament tour = new Tournament(Integer.parseInt(args[0]),render,players);
        tour.playTournament(Integer.parseInt(args[1]),Integer.parseInt(args[2]),playerNames);


    }
}
