import java.util.Random;

public class GeniusPlayer implements Player {
    int size;
    Board board;
    /**
     * strategy: this player will just tring to fill the board row by row as long as the cell is valid and
     * blank else he processed to the next cell in the row
     * @param board
     * @param mark the player mark
     */
    @Override
    public void playTurn(Board board, Mark mark) {
        this.board = board;
        size = board.getSize();
        int row = 0;
        int col = 0;
        if (board.getMark(row, col) == Mark.BLANK) {
            board.putMark(mark, row, col);
        } else {
            while (!board.putMark(mark, row, col)) {
                col++;
                if (col >= size) {
                    col = 0;
                    row++;
                }
            }
        }



    }
}


