public class VoidRenderer implements Renderer{
    @Override
    /**
     * this function mean that the board will not be rendered in every turn during the game
     */
    public void renderBoard(Board board) {

    }
}
