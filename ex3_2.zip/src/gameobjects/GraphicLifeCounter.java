package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

public class GraphicLifeCounter extends GameObject {
    private  Renderable renderable;
    private  GameObject heart1;
    private  GameObject heart2;
    private  GameObject heart3;
    private  Vector2 topLeftCorner;
    private Counter livesCounter;
    public static  Vector2 location;
    private GameObjectCollection gameObjectsCollection;

    private static final int SPACE_BETWEEN_HEARTS = 2;
    private GameObject heart4;


    /**
     * Construct a new GameObject instance. and construct three hearts objects with size 20x20
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     *                      the GameObject will not be rendered.
     */
    public GraphicLifeCounter(Vector2 topLeftCorner, Vector2 dimensions, Counter livesCounter,
                              Renderable renderable, GameObjectCollection gameObjectsCollection, int numOfLives) {
        super(topLeftCorner, dimensions, renderable);
        this.livesCounter = livesCounter;
        this.gameObjectsCollection = gameObjectsCollection;
        this.renderable = renderable;
        this.topLeftCorner = topLeftCorner;
        location = topLeftCorner;
        // size of the hearts live
        Vector2 sizeDimention = new Vector2(20, 20);

         heart1 = new GameObject(topLeftCorner,sizeDimention,renderable);
            gameObjectsCollection.addGameObject(heart1, Layer.UI);
        location = topLeftCorner.add(new Vector2(sizeDimention.x()+SPACE_BETWEEN_HEARTS, 0));
        heart2 = new GameObject(location,sizeDimention,renderable);
            gameObjectsCollection.addGameObject(heart2, Layer.UI);
        location = location.add(new Vector2(sizeDimention.x()+SPACE_BETWEEN_HEARTS, 0));
        heart3 = new GameObject(location,sizeDimention,renderable);
            gameObjectsCollection.addGameObject(heart3, Layer.UI);



    }
    // this functio will create the hearts from the start each time  the livesCounter is updated
    private void createHeart(Counter livesCounter){
        Vector2 sizeDimention = new Vector2(20, 20);
        gameObjectsCollection.removeGameObject(heart1, Layer.UI);
        gameObjectsCollection.removeGameObject(heart2, Layer.UI);
        gameObjectsCollection.removeGameObject(heart3, Layer.UI);
        gameObjectsCollection.removeGameObject(heart4, Layer.UI);
        int count = livesCounter.value();
        if(count == 1) {
            heart1 = new GameObject(topLeftCorner, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart1, Layer.UI);
        }
        if (count ==2) {
            heart1 = new GameObject(topLeftCorner, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart1, Layer.UI);
            location = topLeftCorner.add(new Vector2(sizeDimention.x() + SPACE_BETWEEN_HEARTS, 0));
            heart2 = new GameObject(location, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart2, Layer.UI);
        }
        if(count == 3) {
            heart1 = new GameObject(topLeftCorner, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart1, Layer.UI);
            location = topLeftCorner.add(new Vector2(sizeDimention.x() + SPACE_BETWEEN_HEARTS, 0));
            heart2 = new GameObject(location, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart2, Layer.UI);
            location = location.add(new Vector2(sizeDimention.x() + SPACE_BETWEEN_HEARTS, 0));
            heart3 = new GameObject(location, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart3, Layer.UI);
        }
        if(count == 4){
            heart1 = new GameObject(topLeftCorner, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart1, Layer.UI);
            location = topLeftCorner.add(new Vector2(sizeDimention.x() + SPACE_BETWEEN_HEARTS, 0));
            heart2 = new GameObject(location, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart2, Layer.UI);
            location = location.add(new Vector2(sizeDimention.x() + SPACE_BETWEEN_HEARTS, 0));
            heart3 = new GameObject(location, sizeDimention, renderable);
            gameObjectsCollection.addGameObject(heart3, Layer.UI);
            location = location.add(new Vector2(20+SPACE_BETWEEN_HEARTS, 0));
            heart4 = new GameObject(location,new Vector2(20, 20),renderable);
            gameObjectsCollection.addGameObject(heart4, Layer.UI);
        }
    }


    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        createHeart(livesCounter);

    }
}
