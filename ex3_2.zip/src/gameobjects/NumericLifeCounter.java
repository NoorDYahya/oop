package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Counter;
import danogl.util.Vector2;

import java.awt.*;

public class NumericLifeCounter extends GameObject {
    private Counter livesCounter;
    GameObjectCollection gameObjectCollection;
    TextRenderable textRenderable;

    public NumericLifeCounter(Counter livesCounter, Vector2 topLeftCorner, Vector2 dimensions,
                              GameObjectCollection gameObjectCollection) {
        //pass null to the renderable in the super and them will create the new text rendeble
        super(topLeftCorner, dimensions, null);
        this.livesCounter =livesCounter;
        this.gameObjectCollection = gameObjectCollection;
        int lives = livesCounter.value();
        // create text renderabale
        textRenderable = new TextRenderable(String.format("lives left: "+lives));
        textRenderable.setString(String.format("lives left: "+lives));

        this.renderer().setRenderable(textRenderable);

        GameObject text = new GameObject(topLeftCorner, dimensions,textRenderable);
        this.gameObjectCollection.addGameObject(text,Layer.UI);



    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        textRenderable.setString(String.format("lives left: "+livesCounter.value()));
        // set the text color based on the counter value
        if(livesCounter.value() == 3){
            textRenderable.setColor(Color.GREEN);
        }
        if(livesCounter.value() == 2){
            textRenderable.setColor(Color.yellow);
        }
        if(livesCounter.value() == 1){
            textRenderable.setColor(Color.red);
        }
    }
}
