package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.BrickerGameManager;
import src.gameobjects.Ball;
import src.gameobjects.Puck;
import src.gameobjects.Puck;

public class CameraChangeStrategy extends RemoveBrickStrategy {
    private Ball ball;
    private final BrickerGameManager gameManager;
    private final WindowController windowController;

    CameraChangeStrategy(GameObjectCollection object, Ball ball, BrickerGameManager gameManager,
                         WindowController windowController) {
        super(object);
        this.ball = ball;
        this.gameManager = gameManager;
        this.windowController = windowController;
    }

    /**
     * when collions happen the brike will be removed and the camera will zoom in on the orgin ball and
     * when the ball collide with more than 4 object the zoom will set back out .
     * @param thisObj
     * @param otherObj
     * @param bricksCounter
     */
    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        super.onCollision(thisObj, otherObj, bricksCounter); //remove the brick

        if(otherObj instanceof Ball && !(otherObj instanceof Puck)) // make sure that the object who broke
            // the brick is the orgin ball
        {
            if (gameManager.getCamera() == null) { // if the camera is not already zoomed
                gameManager.setCamera(new Camera(ball, Vector2.ZERO,
                        windowController.getWindowDimensions().mult(1.2f),
                        windowController.getWindowDimensions()));

            }
            if(gameManager.getCamera() != null && ball.getCollisionCount() >4) // if ball's colliosion more
                // than 4 set the camera back to the regular mode
            {
                gameManager.setCamera(null);
            }
        }

    }
}
