package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.util.Counter;
import src.BrickerGameManager;
import src.gameobjects.Ball;

import java.util.Random;

public class DoubleBehaviorStrategy implements CollisionStrategy{
    private  int selected;
    CollisionStrategy strategy1;
    CollisionStrategy strategy2;
    private static final int REMOVE = 0;
    private static final int PUCKS = 1;
    private static final int EXTREAPADDLE = 2;
    private static final int CAMERA = 3;
    private static final int NEWLIVE = 4;
    private ImageReader imagerReader;
    private SoundReader soundReader;
    private UserInputListener inputListener;
    private WindowController windowController;
    private Ball ball;
    private BrickerGameManager gameManager;
    private Counter livesCounter;
    private GameObjectCollection gameObjectCollection;

    /**
     * this constructor will build the chosen strategy based on the passed number of the strategy
     * @param indxStrategy1 number of the first strategy
     * @param indxStrategy2 number of the second strategy
     * @param gameObjectCollection
     * @param imagerReader
     * @param soundReader
     * @param inputListener
     * @param windowController
     * @param ball
     * @param gameManager
     * @param livesCounter
     */
    DoubleBehaviorStrategy(int indxStrategy1 ,int  indxStrategy2 ,GameObjectCollection gameObjectCollection ,
                ImageReader imagerReader, SoundReader soundReader,
                UserInputListener inputListener, WindowController windowController ,
                Ball ball , BrickerGameManager gameManager, Counter livesCounter){
            this.gameObjectCollection = gameObjectCollection;
            this.imagerReader = imagerReader;
            this.soundReader = soundReader;
            this.inputListener = inputListener;
            this.windowController = windowController;
            this.ball = ball;
            this.gameManager = gameManager;
            this.livesCounter = livesCounter;
            // build the strategies
            strategy1 = createBehave(indxStrategy1,strategy1);
            strategy2 = createBehave(indxStrategy2,strategy2);

    }
    // match the number of the strategy to case and build the stratey of it .
    private CollisionStrategy createBehave(int indxStrategy ,CollisionStrategy strategy) {
        switch(indxStrategy){
            case REMOVE:
                strategy = new RemoveBrickStrategy(this.gameObjectCollection);
                break;
            case PUCKS:
                strategy = new AdditionalBallsBehavior(this.gameObjectCollection,imagerReader,soundReader,
                        windowController.getWindowDimensions());
                break;
            case EXTREAPADDLE:
                strategy = new AnotherPaddleStrategy(gameObjectCollection,imagerReader,inputListener,
                        windowController.getWindowDimensions());
                break;
            case CAMERA:
                strategy = new CameraChangeStrategy(gameObjectCollection,ball,gameManager,windowController);
                break;
            case NEWLIVE:
                strategy = new ReturnLiveStrategy(gameObjectCollection ,imagerReader,livesCounter);
                break;
        }
        return strategy;



    }
    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        // call the onCollision function of the two created  strategies
           strategy1.onCollision(thisObj,otherObj,bricksCounter);
           strategy2.onCollision(thisObj,otherObj,bricksCounter);

    }
}
