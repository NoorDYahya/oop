package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.Sound;
import danogl.gui.SoundReader;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Ball;
import src.gameobjects.Puck;

import java.util.Random;

public class AdditionalBallsBehavior extends RemoveBrickStrategy {
    // thi sstategy will add 3 balls from each broken  brick
    private final ImageReader imageReader;
    private final SoundReader soundReader;
    private final GameObjectCollection gameObjects;
    private final static float BALL_SPEED = 100;
    private final Vector2 windowDimensions;

    AdditionalBallsBehavior(GameObjectCollection gameObjects, ImageReader imageReader,
                            SoundReader soundReader ,Vector2 windowDimensions) {
        super(gameObjects);
        this.gameObjects = gameObjects;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
        this.windowDimensions =windowDimensions;

    }


    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        super.onCollision(thisObj, otherObj, bricksCounter); // remove the brick
        //add three balls when collision happen
        int ballLength = (int) thisObj.getDimensions().x() / 3;

        Vector2 bricksCenter = thisObj.getCenter();
//// build the three pucks and them as an objects to the games
        Renderable ballImage = imageReader.readImage("assets/mockBall.png", true);
        Sound collisionSound = soundReader.readSound("assets/blop_cut_silenced.wav");
        // the ball seconde ball should be in the center on the brick the others two are beside it (left,
        // center,right)
        GameObject ball = new Puck(new Vector2(bricksCenter.x() - ballLength,
                bricksCenter.y() - ballLength),
                new Vector2(ballLength,
                        ballLength), ballImage, collisionSound,windowDimensions,gameObjects);
        gameObjects.addGameObject(ball);

        GameObject ball2 = new Puck(bricksCenter,
                new Vector2(ballLength,
                        ballLength), ballImage, collisionSound,windowDimensions,gameObjects);
        gameObjects.addGameObject(ball2);

        GameObject ball3 = new Puck(new Vector2(bricksCenter.x() + ballLength,
                bricksCenter.y() + ballLength),
                new Vector2(ballLength,
                        ballLength), ballImage, collisionSound,windowDimensions,gameObjects);
        gameObjects.addGameObject(ball3);
        /// set the velocity of each new puck to make it move
        float ballVelX = BALL_SPEED;
        float ballVelY = BALL_SPEED;
        Random rand = new Random();

        if (rand.nextBoolean()) {
            ballVelX *= -1;
        }
        if (rand.nextBoolean()) {
            ballVelY *= -1;
        }

        ball.setVelocity(new Vector2(ballVelX, ballVelY));
        ball2.setVelocity(new Vector2(ballVelX, ballVelY));
        ball3.setVelocity(new Vector2(ballVelX, ballVelY));




    }

}
