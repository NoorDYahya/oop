package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.GraphicLifeCounter;
import src.gameobjects.Paddle;

public class ReturnLiveStrategy extends RemoveBrickStrategy{
    private final ImageReader imageReader;
    private final GameObjectCollection gameObjectCollection;
    private static boolean winHeart = false;
    private static final int HEART_SPEED = 100;
    Counter livesCounter;

    ReturnLiveStrategy(GameObjectCollection gameObjectCollection , ImageReader imageReader
            ,Counter livesCounter) {
        super(gameObjectCollection);
        this.imageReader =  imageReader;
        this.gameObjectCollection  = gameObjectCollection;
        this.livesCounter = livesCounter;

    }

    /**
     * when colliosin happen beatween the brick and the ball the first will be removed and an heart will
     * fall down from the center of the paddle
     * @param thisObj in this case this object is the paddle
     * @param otherObj this object is the ball
     * @param bricksCounter bricks counter
     */
    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        super.onCollision(thisObj, otherObj, bricksCounter); // remove the brick
        /// start creating the falling heart
        Vector2 sizeDimention = new Vector2(20, 20);
        Renderable heartImage = imageReader.readImage("assets/heart.png", true);
        Heart heart = new Heart(thisObj.getCenter() ,sizeDimention, heartImage ,gameObjectCollection,
                livesCounter);
        // in order to make it falling we set a velocity for it
        heart.setVelocity(new Vector2(0,HEART_SPEED));
        // adding the heart to the game objects
        gameObjectCollection.addGameObject(heart,Layer.STATIC_OBJECTS);

    }
}
