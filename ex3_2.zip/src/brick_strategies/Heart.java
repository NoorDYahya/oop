package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Ball;
import src.gameobjects.Paddle;

public class Heart extends GameObject {


    private final GameObjectCollection gameObjectCollection;
    private final Counter livesCounter;
    private final Renderable heartImage;



    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param heartImage    The renderable representing the object. Can be null, in which case
     *                      the GameObject will not be rendered.
     */
    public Heart(Vector2 topLeftCorner, Vector2 dimensions, Renderable heartImage, GameObjectCollection
                 gameObjectCollection, Counter livesCounter) {
        super(topLeftCorner, dimensions, heartImage);
        this.gameObjectCollection = gameObjectCollection;
        this.livesCounter = livesCounter;
        this.heartImage = heartImage;


    }

    /**
     * this function will limit the heart's collisions to be just with the paddle and the also the new
     * added paddle in other startied
     * @param other The other GameObject.
     * @return
     */
    @Override
    public boolean shouldCollideWith(GameObject other) {
// make sure that it is instance of pAddle and not NewPaddle case the second inherate the first one.
        if(other instanceof Paddle && !(other instanceof NewPaddle)){
            return true;
        }
        return false;

    }

    /**
     * when colliosn happen just between the paddle and the heart , the heart will be romoved and the
     * counter will be added by one as long as the overall live counter less than 4.
     * @param other The GameObject with which a collision occurred.
     * @param collision Information regarding this collision.
     *                  A reasonable elastic behavior can be achieved with:
     *                  setVelocity(getVelocity().flipped(collision.getNormal()));
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if(other instanceof Paddle && !(other instanceof NewPaddle)){
            gameObjectCollection.removeGameObject(this,Layer.STATIC_OBJECTS);
            if(livesCounter.value() <= 3)
            {
                livesCounter.increment();

            }

        }
    }

}
