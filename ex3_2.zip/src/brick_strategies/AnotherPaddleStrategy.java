package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.Sound;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Brick;
import src.gameobjects.Paddle;


public class AnotherPaddleStrategy extends RemoveBrickStrategy {
    private final static int MIN_DISTANCE_FROM_SCREEN_EDGE = 1;
    private final ImageReader imageReader;
    private final UserInputListener inputListener;
    private final GameObjectCollection gameObjectCollection;
    private Vector2 windowDimensions;
    private static NewPaddle paddle = null;
    private int count = 0;

    AnotherPaddleStrategy(GameObjectCollection gameObjectCollection,
                          ImageReader imageReader,
                          UserInputListener inputListener, Vector2 windowDimensions) {
        super(gameObjectCollection);
        this.imageReader = imageReader;
        this.inputListener = inputListener;
        this.windowDimensions = windowDimensions;
        this.gameObjectCollection = gameObjectCollection;


    }

    /**
     * when this function called this mean that abrick with this strategy id broke and the paddle should
     * appear
     * @param thisObj
     * @param otherObj
     * @param bricksCounter
     */
    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        super.onCollision(thisObj, otherObj, bricksCounter); /// remove the brick

        if(!gameObjectCollection.removeGameObject(paddle)) // this condition will make sure that there is
            // no already newpaddle in the screen and then it will add new one
        {
            ///build the new paddle
            Renderable paddleImage = imageReader.readImage("assets/botGood.png"
                    , true);
            paddle = new NewPaddle(Vector2.ZERO, new Vector2(150, 10), paddleImage, this.inputListener,
                    windowDimensions, MIN_DISTANCE_FROM_SCREEN_EDGE, gameObjectCollection);
            paddle.setCenter(new Vector2(windowDimensions.x() / 2, windowDimensions.y() / 2));
            gameObjectCollection.addGameObject(paddle);

        }





    }
}
