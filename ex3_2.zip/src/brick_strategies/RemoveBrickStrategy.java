package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.util.Counter;

public class RemoveBrickStrategy implements CollisionStrategy {
    private GameObjectCollection gameObjects;

    RemoveBrickStrategy(GameObjectCollection object) {
        this.gameObjects = object;

    }

    public void onCollision(GameObject thisObj, GameObject otherObj, Counter bricksCounter) {
        System.out.println("collision with brick detected");
        /// in case and the collision occur and the function remove the brick it also will decrease the
        // counter of the bricks by one
        if (gameObjects.removeGameObject(thisObj, Layer.STATIC_OBJECTS)) {
            bricksCounter.decrement();

        }
    }
}