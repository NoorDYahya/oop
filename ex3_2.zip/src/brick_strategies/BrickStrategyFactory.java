package src.brick_strategies;

import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.BrickerGameManager;
import src.gameobjects.Ball;

import javax.swing.*;
import java.util.Random;

public class BrickStrategyFactory {
    private final ImageReader imagerReader;
    private final SoundReader soundReader;
    private final UserInputListener inputListener;
    private final WindowController windowController;
    private final Ball ball;
    private final BrickerGameManager gameManager;
    private final Counter livesCounter;
    private GameObjectCollection gameObjectCollection;
    private int arg ;
    private static final int REMOVE = 0;
    private static final int PUCKS = 1;
    private static final int EXTREAPADDLE = 2;
    private static final int CAMERA = 3;
    private static final int NEWLIVE = 4;
    private static final int DOUBLE= 5;
    int[]   behave = new int[]{REMOVE,PUCKS,EXTREAPADDLE,CAMERA,NEWLIVE,DOUBLE};
    int attempts;
    private int selected2;
    private int selected;

    public BrickStrategyFactory(int arg , GameObjectCollection gameObjectCollection ,
                                ImageReader imagerReader, SoundReader soundReader,
                                UserInputListener inputListener, WindowController windowController ,
                                Ball ball , BrickerGameManager gameManager, Counter livesCounter) {
        this.arg = arg;
        this.gameObjectCollection = gameObjectCollection;
        this.imagerReader = imagerReader;
        this.soundReader = soundReader;
        this.inputListener = inputListener;
        this.windowController = windowController;
        this.ball = ball;
        this.gameManager = gameManager;
        this.livesCounter = livesCounter;

    }

    /**
     * this function will run in case and the first random selection was double behaviour and will choose
     * randomly two behaviours to apply .
     */
    private void selectBehaveForDouble(){
        Random random = new Random();
        //select randomly a behaviour between the 1-5 special behaviours and in case and the results is
        // double so the second selection should not include double behaviours
        selected = random.nextInt(1,6);
        if(behave[selected] == DOUBLE ){
            selected2 = random.nextInt(5); //we have two double behaviors then the second selection
            // should be without double behavior

            selected = random.nextInt(5); // select a behaviour include remove behaviour


        }
        else
        {//in case and the first selection is not double
            selected2 = random.nextInt(6); // the second selection could be anything
            if(behave[selected2] == DOUBLE){
                selected2 = random.nextInt(5);
            }
        }
    }

    /**
     * this function will build the strategy based on the passed number from the constructor
     * @return
     */
    public CollisionStrategy getStrategy() {
        CollisionStrategy strategy = null;
        //choose randomly between the possible brick strategies
        switch(arg){
            case REMOVE:
                strategy = new RemoveBrickStrategy(this.gameObjectCollection);
                break;
            case PUCKS:
                strategy = new AdditionalBallsBehavior(this.gameObjectCollection,imagerReader,soundReader,
                        windowController.getWindowDimensions());
                break;
            case EXTREAPADDLE:
                strategy = new AnotherPaddleStrategy(gameObjectCollection,imagerReader,inputListener,
                        windowController.getWindowDimensions());
                break;
            case CAMERA:
                strategy = new CameraChangeStrategy(gameObjectCollection,ball,gameManager,windowController);
                break;
            case NEWLIVE:
                strategy = new ReturnLiveStrategy(gameObjectCollection ,imagerReader,livesCounter);
                break;
            case DOUBLE:
                selectBehaveForDouble();
                strategy = new DoubleBehaviorStrategy(selected,selected2,gameObjectCollection ,
                        imagerReader, soundReader,
                         inputListener,  windowController ,
                        ball ,  gameManager,  livesCounter);
                break;
        }
        return strategy;
    }
}