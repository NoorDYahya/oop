package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import src.gameobjects.Ball;
import src.gameobjects.Paddle;
import src.gameobjects.Puck;

public class NewPaddle extends Paddle{
    private static int counter = 0; // counter of the number of times that the ball collide with newpaddle
    boolean flag = false;
    private final GameObjectCollection gameObjectCollection;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner    Position of the object, in window coordinates (pixels).
     *                         Note that (0,0) is the top-left corner of the window.
     * @param dimensions       Width and height in window coordinates.
     * @param renderable       The renderable representing the object. Can be null, in which case
     *                         the GameObject will not be rendered.
     * @param inputListener
     * @param windowDimensions
     * @param minDistFromEdge
     */
    public NewPaddle(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                     UserInputListener inputListener, Vector2 windowDimensions, int minDistFromEdge,
                     GameObjectCollection gameObjectCollection) {
        super(topLeftCorner, dimensions, renderable, inputListener, windowDimensions, minDistFromEdge);
        this.gameObjectCollection = gameObjectCollection;
    }


    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if(other instanceof Ball){   // will count just the collliosions with the ball
            counter++;
        }
        if (counter >= 3) {   // in case and the number of colliosions is lager than 3 the newpaddle will
            // be removed and the counter will be set to zero in case and another brick using this
            // strategy ,so it will add a new paddle then the counter will count from the start

            this.gameObjectCollection.removeGameObject(this);
            counter = 0;
        }

    }



}
