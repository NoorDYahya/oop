package src;

import src.brick_strategies.BrickStrategyFactory;
import src.brick_strategies.CollisionStrategy;
import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.components.CoordinateSpace;
import danogl.gui.*;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.*;
import java.awt.event.KeyEvent;
import java.util.Random;

public class BrickerGameManager extends GameManager {
    public final static int BORDER_WIDTH = 5;
    private static final int MIN_DISTANCE_FROM_SCREEN_EDGE = 1;
    private final static int BRICK_HEIGHT = 15;
    private final static int SPACING_BETWEEN_BRICKS_WINDOW = 5;
    private final static int SPACING_BETWEEN_BRICKS = 1;
    private static final float BALL_SPEED = 200;
    private Ball ball;
    private Vector2 windowDimensions;
    private WindowController windowController;
    private Counter counterBricks;
    private Counter livesCounter;
    private Counter numericCounter;
    private UserInputListener inputListener;
    private static int numOfLives = 3;
    private SoundReader soundReader;
    private ImageReader imageReader;
    Random random;

    public BrickerGameManager(String windowTitle, Vector2 windowDimentions) {
        super(windowTitle, windowDimentions);
    }

    private void createBall(ImageReader imageReader, SoundReader soundReader, Vector2 windowDimensions) {
        Renderable ballImage = imageReader.readImage("assets/ball.png", true);
        Sound collisionSound = soundReader.readSound("assets/blop_cut_silenced.wav");
        ball = new Ball(Vector2.ZERO, new Vector2(20, 20), ballImage, collisionSound);
        ball.setCenter(windowDimensions.mult((float) 0.5));
        this.gameObjects().addGameObject(ball);
        float ballVelX = BALL_SPEED;
        float ballVelY = BALL_SPEED;
        Random rand = new Random();
        if (rand.nextBoolean()) {
            ballVelX *= -1;
        }
        if (rand.nextBoolean()) {
            ballVelY *= -1;
        }
        ball.setVelocity(new Vector2(ballVelX, ballVelY));
    }

    /**
     * this function will create the paddle and add it to the game objects
     * @param paddleImage
     * @param inputListener
     * @param windowDimensions
     */
    private void createUserPaddle(Renderable paddleImage, UserInputListener inputListener,
                                  Vector2 windowDimensions) {
        // create the paddle
        Paddle paddle = new Paddle(Vector2.ZERO, new Vector2(150, 10), paddleImage, inputListener,
                windowDimensions, MIN_DISTANCE_FROM_SCREEN_EDGE);
        // set the paddle to middle of the center of the screan with below location :
        paddle.setCenter(new Vector2(windowDimensions.x() / 2, (int) windowDimensions.y() - 30));
        gameObjects().addGameObject(paddle);
    }

    /**
     * this function will create the background and add it to the game objects and its cover all the screen
     * size
     * @param imageReader
     * @param windowDimensions
     */
    private void createBackground(ImageReader imageReader, Vector2 windowDimensions) {
        Renderable backgroundImage = imageReader.readImage("assets/DARK_BG2_small.jpeg",
                false);
        GameObject background = new GameObject(
                Vector2.ZERO,
                windowDimensions,
                backgroundImage);
        background.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        gameObjects().addGameObject(background, Layer.BACKGROUND);

    }

    /**
     * this function will create graphic hearts counter ,0x0 size such that it doesn't appear in the screan
     * @param imageReader
     */
    private void createHears(ImageReader imageReader) {
        Vector2 topLeftCorner = new Vector2(20, (int) windowDimensions.y() - 30);
        Renderable heartImage = imageReader.readImage("assets/heart.png", true);

        GameObject heart = new GraphicLifeCounter(topLeftCorner,
                    new Vector2(0,0), livesCounter, heartImage, gameObjects(), numOfLives);
        gameObjects().addGameObject(heart);

    }

    /**
     * this function will create one numeric counter and add it to the game objects
     *
     * @param windowDimensions
     */
    private void createNemuric(Vector2 windowDimensions) {
//        it will show the counter on the screen and update it each time based on the lives counter we pass
        Vector2 counterSize = new Vector2(20, 20);
        // the counter is in the same paddle location.x() added by 70 , 20x20 size
        GameObject counter = new NumericLifeCounter(livesCounter, new Vector2(20,
                (int) windowDimensions.y() - 30).add(new Vector2(100, 0)),
                counterSize, this.gameObjects());

        gameObjects().addGameObject(counter, Layer.UI);

    }

    /**
     * this function will create the borders , top , left and right
     * and add them to the game obejcts
     * @param windowDimensions
     */
    private void createBorders(Vector2 windowDimensions) {
        GameObject leftBorder = new GameObject(
                //anchored at top-left corner of the screen
                Vector2.ZERO,

                //height of border is the height of the screen
                new Vector2(BORDER_WIDTH, windowDimensions.y()),

                //this game object is invisible; it doesn’t have a Renderable
                null
        );
        GameObject rightBorder = new GameObject(Vector2.ZERO.add(new Vector2(windowDimensions.x(), 0)),
                new Vector2(BORDER_WIDTH,
                        windowDimensions.y()),
                null);
        GameObject topBorder = new GameObject(Vector2.ZERO, new Vector2(
                windowDimensions.x(), BORDER_WIDTH),
                null);
        gameObjects().addGameObject(leftBorder, Layer.DEFAULT);
        gameObjects().addGameObject(rightBorder, Layer.DEFAULT);
        gameObjects().addGameObject(topBorder, Layer.DEFAULT);


    }

    /**
     * this function will create one brick using the Brick constructor and add it to the game objects
     * also it will increace the brick counter by one
     * @param imageReader
     * @param Dimensions
     * @param brickWidth
     */
    private void createBrick(ImageReader imageReader, Vector2 Dimensions, int brickWidth ,
                             BrickStrategyFactory factory ) {
        Renderable brickImage = imageReader.readImage("assets/brick.png", true);
        CollisionStrategy collisionStrategy = factory.getStrategy();
        counterBricks.increment();
        GameObject brick = new Brick(Dimensions, new Vector2(brickWidth, BRICK_HEIGHT),
                brickImage, collisionStrategy, counterBricks);
        this.gameObjects().addGameObject(brick, Layer.STATIC_OBJECTS);

    }

    /**
     * this function will check if one of the three conditions of ending the game is accomplished
     */
    private void checkForGameEnd() {
        String prompt = "";
        if (livesCounter.value() == 0) { // live counter is zero witch mean that the player loss the game
            // after 3 attempts
            prompt = "You Lost!";
            prompt += " Play again?";
            // ask the user if he wants to play another game
            if (windowController.openYesNoDialog(prompt)) { // if the user pressed yes
                windowController.resetGame(); // the game will start again
            } else {
                windowController.closeWindow(); // else it will close the window and stop the game running
            }
        }

        if (counterBricks.value() == 0) { // counter bricks zero witch mean that the player win the game
            // , he broke all the 56 bricks in the game
            prompt = "You Win!";
            System.out.println(prompt);
            prompt += " Play again?";
            // ask the user if he wants to play another game
            if (windowController.openYesNoDialog(prompt)) {
                windowController.resetGame();
            } else {
                windowController.closeWindow();
            }


        }
        // in case that the user press "w" in the keyboard we shold stop the game and ask him for another
        // game
        if (inputListener.isKeyPressed(KeyEvent.VK_W)) {
            prompt = "You Win!";
            prompt += " Play again?";
            if (windowController.openYesNoDialog(prompt)) {
                windowController.resetGame();
            } else {
                windowController.closeWindow();
            }

        }

    }

    /**
     * this function is overwritten such that in case of that as long as the number of lives is not zero the
     *  and the ball fall down out of the screen , the game will countinue with the last amount of
     *  disappear bricks but such that the ball with be setted to the center
     *
     * @param deltaTime The time, in seconds, that passed since the last invocation
     *                  of this method (i.e., since the last frame). This is useful
     *                  for either accumulating the total time that passed since some
     *                  event, or for physics integration (i.e., multiply this by
     *                  the acceleration to get an estimate of the added velocity or
     *                  by the velocity to get an estimate of the difference in position).
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);

        Random rand = new Random();
        float ballVelX = BALL_SPEED;
        float ballVelY = BALL_SPEED;
        double ballHeight = ball.getCenter().y();
        checkForGameEnd();// check if the there is a win from the first attempt
        if (ballHeight > windowDimensions.y()) { // if the ball fal down out of the screan size
            livesCounter.decrement(); // decrease the lives number by one
            ball.setCenter(windowDimensions.mult((float) 0.5));
            windowController.setTargetFramerate(80);
            ball.setCenter(windowDimensions.mult((float) 0.5)); // set ball to the center of the screen to
            // start again
            if (rand.nextBoolean()) { // set the velocity again in order to make it move again , choose
                // randomly the direction of the ball move
                ballVelX *= -1;
            }
            if (rand.nextBoolean()) {
                ballVelY *= -1;
            }
            ball.setVelocity(new Vector2(ballVelX, ballVelY));
        }
        checkForGameEnd();
    }

    @Override
    public void initializeGame(ImageReader imageReader, SoundReader soundReader,
                               UserInputListener inputListener, WindowController windowController) {
        this.windowController = windowController;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
        //        initialization
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        counterBricks = new Counter(0);
        livesCounter = new Counter(3);
        windowController.setTargetFramerate(80);
        this.inputListener = inputListener;
        windowDimensions = windowController.getWindowDimensions();
        // creating ball
        createBall(imageReader, soundReader, windowDimensions);

        // create user  paddle
        Renderable paddleImage = imageReader.readImage("assets/paddle.png", true);
        createUserPaddle(paddleImage, inputListener, windowDimensions);


        // create borders
        createBorders(windowDimensions);
        //create wall
        GameObject wall = new GameObject(Vector2.ZERO, new Vector2(BORDER_WIDTH, windowDimensions.y()),
                null);
        gameObjects().addGameObject(wall, Layer.BACKGROUND);

        // CREATE background
        createBackground(imageReader, windowDimensions);
        //nemuric counter
        createNemuric(windowDimensions);
        //hearts
        createHears(imageReader);

        // create 56 bricks
        int helperSpaces = 2*SPACING_BETWEEN_BRICKS_WINDOW + SPACING_BETWEEN_BRICKS*7; // space from wimdow
        // from both sides and spacing between 8 bricks each row
        int brickWidth = (int) ((windowDimensions.x() - helperSpaces) / 7);
        Vector2 vec = Vector2.ZERO.add(new Vector2(SPACING_BETWEEN_BRICKS_WINDOW,
                SPACING_BETWEEN_BRICKS_WINDOW));
        int y = 0;
        random = new Random();
        for (int i = 0; i < 8; i++) { // 8 rows
            //  7 bricks ech row
            int selected = random.nextInt(6);

            BrickStrategyFactory factory = new BrickStrategyFactory(selected,this.gameObjects(),imageReader,
                    soundReader,inputListener,windowController,ball,this,livesCounter);

            createBrick(imageReader, vec, brickWidth,factory); // create the first brick from the top-left in
            // each row
            for (int j = 0; j < 7; j++) { // create the rest 7 bricks in each row
                selected = random.nextInt(6);

                factory = new BrickStrategyFactory(selected,this.gameObjects(),imageReader,
                        soundReader,inputListener,windowController,ball,this,livesCounter);
                createBrick(imageReader, vec.add(new Vector2(brickWidth + SPACING_BETWEEN_BRICKS, 0)),
                        brickWidth,factory);
                vec = vec.add(new Vector2(brickWidth + SPACING_BETWEEN_BRICKS, 0));
            }
            y += BRICK_HEIGHT + 1; // NOW ROW OF BRICKS
            vec = Vector2.ZERO.add(new Vector2(5, 5 + y));
        }



    }

    public static void main(String[] args) {
                new BrickerGameManager("Bouncing ball", new Vector2(700, 500)).run();

    }


}
